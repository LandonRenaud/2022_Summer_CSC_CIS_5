

/* 
 * File:   main.cpp
 * Author: landon Renaud
 * Created on July 24, 2022, 11:42 AM
 * Purpose: prototype a system for a more sophisticated ai
 */

#include <cstdlib>
#include <ctime>
#include <cmath>
#include <string>
#include <iostream>
using namespace std;

int main(int argc, char** argv) {
   //Initialize the Random Number Seed
    srand(static_cast<unsigned short>(time(0)));
    
    //Declare Variables
    unsigned short dcount,  // destroyer count
                   bttlcnt, // battleship count
                   cpuatkn, // a number to be randomly generated to determine where the CPU will attack 
                   roundno; // a variable to track the number of rounds, which will be displayed at the end of the game
    unsigned int wincnt = 0,  // tracks the number of player wins for the purpose of win rate calculation
                 gamenum = 0; // tracks the current game number for the purpose of win rate calculation
    float winrate; // a value to be calculated at the end, where the program will tell the user their win rate across
                   // all the games they've played
    char again,
         schoice, // ship choice
         clearwr; // a variable to hold y/n, used to determine whether the player wishes to clear the win record
    unsigned short direc;
    string tile,
           acoordP, // the attack coordinate of the player
           acoordC = "0"; // the attack coordinate of the CPU
    bool gamest = true, // game state variable, once game state is false the game will end, 
                        // and the player will be asked if they want to play again
         playerW;     // a variable for storing win rate, if the player wins, it equals 1, if the CPU wins, it equals 0
    // player board variables
    unsigned short a1 = 0, a2 = 0, a3 = 0, a4 = 0, a5 = 0,
                   b1 = 0, b2 = 0, b3 = 0, b4 = 0, b5 = 0,
                   c1 = 0, c2 = 0, c3 = 0, c4 = 0, c5 = 0,
                   d1 = 0, d2 = 0, d3 = 0, d4 = 0, d5 = 0,
                   e1 = 0, e2 = 0, e3 = 0, e4 = 0, e5 = 0,
                   hitnumP = 0; // tracks the number of hits made by the player, if the number reaches 7, the player wins
    // CPU board variables
    unsigned short ca1 = 0, ca2 = 0, ca3 = 0, ca4 = 3, ca5 = 0,
                   cb1 = 0, cb2 = 2, cb3 = 0, cb4 = 3, cb5 = 0,
                   cc1 = 0, cc2 = 2, cc3 = 0, cc4 = 3, cc5 = 0,
                   cd1 = 0, cd2 = 0, cd3 = 0, cd4 = 0, cd5 = 0,
                   ce1 = 0, ce2 = 0, ce3 = 0, ce4 = 2, ce5 = 2,
                   hitnumC = 0; // tracks the number of hits made by the CPU, if the number reaches 7, the CPU wins
    // CPU ai variables
    bool isHita1 = false, isHita2 = false, isHita3 = false, isHita4 = false, isHita5 = false, 
         isHitb1 = false, isHitb2 = false, isHitb3 = false, isHitb4 = false, isHitb5 = false, 
         isHitc1 = false, isHitc2 = false, isHitc3 = false, isHitc4 = false, isHitc5 = false, 
         isHitd1 = false, isHitd2 = false, isHitd3 = false, isHitd4 = false, isHitd5 = false, 
         isHite1 = false, isHite2 = false, isHite3 = false, isHite4 = false, isHite5 = false; 
            
            
            cpuatkn = (static_cast<int>(sqrt(int(rand())))%25)+1; // sets random number to determine the space the CPU will attack
            cout << cpuatkn << endl;
            /*
             * Pseudo Code:
             * find a random number from 1 to 25
             * 1-5 represents a1-a5 respectively
             * 6-10 represents b1-b5 respectively
             * 11-15 represents c1-c5 respectively
             * 16-20 represents d1-d5 respectively
             * 21-25 represents e1-e5 respectively
             * 
             * if: the selected tile has already been attacked,
             * go to the next tile
             * 
             * if: the CPU's target is an empty tile,
             * output: "Miss!"
             * add 1 to the variable for that tile
             * else if: the CPU's target has a destroyer on it,
             * add 2 to the variable for that tile
             * else if: the CPU's target has a battleship on it,
             * add 1 to the variable for that tile
             * 
             */
            
            for(int n = 0; (n < 25) && (acoordC == "0"); n++) {
                cout << acoordC;
                if(cpuatkn == 1) {
                    if(isHita1 == false) {
                        cpuatkn++;
                    } else acoordC = "a1";
                } else if(cpuatkn == 2) {
                    if(isHita2 == true) {
                        cpuatkn++;
                    } else acoordC = "a2";
                } else if(cpuatkn == 3) {
                    if(isHita3 == true) {
                        cpuatkn++;
                    } else acoordC = "a3";
                } else if(cpuatkn == 4) {
                    if(isHita4 == true) {
                        cpuatkn++;
                    } else acoordC = "a4";
                } else if(cpuatkn == 5) {
                    if(isHita5 == true) {
                        cpuatkn++;
                    } else acoordC = "a5";
                } else if(cpuatkn == 6) {
                    if(isHitb1 == true) {
                        cpuatkn++;
                    } else acoordC = "b1";
                } else if(cpuatkn == 7) {
                    if(isHitb2 == true) {
                        cpuatkn++;
                    } else acoordC = "b2";
                } else if(cpuatkn == 8) {
                    if(isHitb3 == true) {
                        cpuatkn++;
                    } else acoordC = "b3";
                } else if(cpuatkn == 9) {
                    if(isHitb4 == true) {
                        cpuatkn++;
                    } else acoordC = "b4";
                } else if(cpuatkn == 10) {
                    if(isHitb5 == true) {
                        cpuatkn++;
                    } else acoordC = "b5";
                } else if(cpuatkn == 11) {
                    if(isHitc1 == true) {
                        cpuatkn++;
                    } else acoordC = "c1";
                } else if(cpuatkn == 12) {
                    if(isHitc2 == true) {
                        cpuatkn++;
                    } else acoordC = "c2";
                } else if(cpuatkn == 13) {
                    if(isHitc3 == true) {
                        cpuatkn++;
                    } else acoordC = "c3";
                } else if(cpuatkn == 14) {
                    if(isHitc4 == true) {
                        cpuatkn++;
                    } else acoordC = "c4";
                } else if(cpuatkn == 15) {
                    if(isHitc5 == true) {
                        cpuatkn++;
                    } else acoordC = "c5";
                } else if(cpuatkn == 16) {
                    if(isHitd1 == true) {
                        cpuatkn++;
                    } else acoordC = "d1";
                } else if(cpuatkn == 17) {
                    if(isHitd2 == true) {
                        cpuatkn++;
                    } else acoordC = "d2";
                } else if(cpuatkn == 18) {
                    if(isHitd3 == true) {
                        cpuatkn++;
                    } else acoordC = "d3";
                } else if(cpuatkn == 19) {
                    if(isHitd4 == true) {
                        cpuatkn++;
                    } else acoordC = "d4";
                } else if(cpuatkn == 20) {
                    if(isHitd5 == true) {
                        cpuatkn++;
                    } else acoordC = "d5";
                } else if(cpuatkn == 21) {
                    if(isHite1 == true) {
                        cpuatkn++;
                    } else acoordC = "e1";
                } else if(cpuatkn == 22) {
                    if(isHite2 == true) {
                        cpuatkn++;
                    } else acoordC = "e2";
                } else if(cpuatkn == 23) {
                    if(isHite3 == true) {
                        cpuatkn++;
                    } else acoordC = "e3";
                } else if(cpuatkn == 24) {
                    if(isHite4 == true) {
                        cpuatkn++;
                    } else acoordC = "e4";
                } else if(cpuatkn == 25) {
                    if(isHite5 == true) {
                        cpuatkn++;
                    } else acoordC = "e5";
                }
            cpuatkn = (cpuatkn > 25)? 1:cpuatkn; // overflow, if the CPU attack number goes above 25, it is reset back to 1
            }
            
            cout << "\n\nThe CPU Attacked " << acoordC << "!\n";
            // Uses the variables for the player's board (a1, a2,... etc..)
            // since the CPU is attacking the player's board tiles
            if(acoordC == "a1") {
                if(a1 == 0) {
                    a1++;
                    cout << "Miss!";
                } else if(a1 == 2) {
                    a1 += 2;
                    hitnumC++;
                    cout << "Hit!";
                } else if(a1 == 3) {
                    a1++;
                    hitnumC++;
                    cout << "Hit!";
                }
                isHita1 = true;
            } else if(acoordC == "a2") {
                if(a2 == 0) {
                    a2++;
                    cout << "Miss!";
                } else if(a2 == 2) {
                    a2 += 2;
                    hitnumC++;
                    cout << "Hit!";
                } else if(a2 == 3) {
                    a2++;
                    hitnumC++;
                    cout << "Hit!";
                }
                isHita2 = true;
            } else if(acoordC == "a3") {
                if(a3 == 0) {
                    a3++;
                    cout << "Miss!";
                } else if(a3 == 2) {
                    a3 += 2;
                    hitnumC++;
                    cout << "Hit!";
                } else if(a3 == 3) {
                    a3++;
                    hitnumC++;
                    cout << "Hit!";
                }
                isHita3 = true;
            } else if(acoordC == "a4") {
                if(a4 == 0) {
                    a4++;
                    cout << "Miss!";
                } else if(a4 == 2) {
                    a4 += 2;
                    hitnumC++;
                    cout << "Hit!";
                } else if(a4 == 3) {
                    a4++;
                    hitnumC++;
                    cout << "Hit!";
                }
                isHita4 = true;
            } else if(acoordC == "a5") {
                if(a5 == 0) {
                    a5++;
                    cout << "Miss!";
                } else if(a5 == 2) {
                    a5 += 2;
                    hitnumC++;
                    cout << "Hit!";
                } else if(a5 == 3) {
                    a5++;
                    hitnumC++;
                    cout << "Hit!";
                }
                isHita5 = true;
            } else if(acoordC == "b1") {
                if(b1 == 0) {
                    b1++;
                    cout << "Miss!";
                } else if(b1 == 2) {
                    b1 += 2;
                    hitnumC++;
                    cout << "Hit!";
                } else if(b1 == 3) {
                    b1++;
                    hitnumC++;
                    cout << "Hit!";
                }
                isHitb1 = true;
            } else if(acoordC == "b2") {
                if(b2 == 0) {
                    b2++;
                    cout << "Miss!";
                } else if(b2 == 2) {
                    b2 += 2;
                    hitnumC++;
                    cout << "Hit!";
                } else if(b2 == 3) {
                    b2++;
                    hitnumC++;
                    cout << "Hit!";
                }
                isHitb2 = true;
            } else if(acoordC == "b3") {
                if(b3 == 0) {
                    b3++;
                    cout << "Miss!";
                } else if(b3 == 2) {
                    b3 += 2;
                    hitnumC++;
                    cout << "Hit!";
                } else if(b3 == 3) {
                    b3++;
                    hitnumC++;
                    cout << "Hit!";
                }
                isHitb3 = true;
            } else if(acoordC == "b4") {
                if(b4 == 0) {
                    b4++;
                    cout << "Miss!";
                } else if(b4 == 2) {
                    b4 += 2;
                    hitnumC++;
                    cout << "Hit!";
                } else if(b4 == 3) {
                    b4++;
                    hitnumC++;
                    cout << "Hit!";
                }
                isHitb4 = true;
            } else if(acoordC == "b5") {
                if(b5 == 0) {
                    b5++;
                    cout << "Miss!";
                } else if(b5 == 2) {
                    b5 += 2;
                    hitnumC++;
                    cout << "Hit!";
                } else if(b5 == 3) {
                    b5++;
                    hitnumC++;
                    cout << "Hit!";
                }
                isHitb5 = true;
            } else if(acoordC == "c1") {
                if(c1 == 0) {
                    c1++;
                    cout << "Miss!";
                } else if(c1 == 2) {
                    c1 += 2;
                    hitnumC++;
                    cout << "Hit!";
                } else if(c1 == 3) {
                    c1++;
                    hitnumC++;
                    cout << "Hit!";
                }
                isHitc1 = true;
            } else if(acoordC == "c2") {
                if(c2 == 0) {
                    c2++;
                    cout << "Miss!";
                } else if(c2 == 2) {
                    c2 += 2;
                    hitnumC++;
                    cout << "Hit!";
                } else if(c2 == 3) {
                    c2++;
                    hitnumC++;
                    cout << "Hit!";
                }
                isHitc2 = true;
            } else if(acoordC == "c3") {
                if(c3 == 0) {
                    c3++;
                    cout << "Miss!";
                } else if(c3 == 2) {
                    c3 += 2;
                    hitnumC++;
                    cout << "Hit!";
                } else if(c3 == 3) {
                    c3++;
                    hitnumC++;
                    cout << "Hit!";
                }
                isHitc3 = true;
            } else if(acoordC == "c4") {
                if(c4 == 0) {
                    c4++;
                    cout << "Miss!";
                } else if(c4 == 2) {
                    c4 += 2;
                    hitnumC++;
                    cout << "Hit!";
                } else if(c4 == 3) {
                    c4++;
                    hitnumC++;
                    cout << "Hit!";
                }
                isHitc4 = true;
            } else if(acoordC == "c5") {
                if(c5 == 0) {
                    c5++;
                    cout << "Miss!";
                } else if(c5 == 2) {
                    c5 += 2;
                    hitnumC++;
                    cout << "Hit!";
                } else if(c5 == 3) {
                    c5++;
                    hitnumC++;
                    cout << "Hit!";
                }
                isHitc5 = true;
            } else if(acoordC == "d1") {
                if(d1 == 0) {
                    d1++;
                    cout << "Miss!";
                } else if(d1 == 2) {
                    d1 += 2;
                    hitnumC++;
                    cout << "Hit!";
                } else if(d1 == 3) {
                    d1++;
                    hitnumC++;
                    cout << "Hit!";
                }
                isHitd1 = true;
            } else if(acoordC == "d2") {
                if(d2 == 0) {
                    d2++;
                    cout << "Miss!";
                } else if(d2 == 2) {
                    d2 += 2;
                    hitnumC++;
                    cout << "Hit!";
                } else if(d2 == 3) {
                    d2++;
                    hitnumC++;
                    cout << "Hit!";
                }
                isHitd2 = true;
            } else if(acoordC == "d3") {
                if(d3 == 0) {
                    d3++;
                    cout << "Miss!";
                } else if(d3 == 2) {
                    d3 += 2;
                    hitnumC++;
                    cout << "Hit!";
                } else if(d3 == 3) {
                    d3++;
                    hitnumC++;
                    cout << "Hit!";
                }
                isHitd3 = true;
            } else if(acoordC == "d4") {
                if(d4 == 0) {
                    d4++;
                    cout << "Miss!";
                } else if(d4 == 2) {
                    d4 += 2;
                    hitnumC++;
                    cout << "Hit!";
                } else if(d4 == 3) {
                    d4++;
                    hitnumC++;
                    cout << "Hit!";
                }
                isHitd4 = true;
            } else if(acoordC == "d5") {
                if(d5 == 0) {
                    d5++;
                    cout << "Miss!";
                } else if(d5 == 2) {
                    d5 += 2;
                    hitnumC++;
                    cout << "Hit!";
                } else if(d5 == 3) {
                    d5++;
                    hitnumC++;
                    cout << "Hit!";
                }
                isHitd5 = true;
            } else if(acoordC == "e1") {
                if(e1 == 0) {
                    e1++;
                    cout << "Miss!";
                } else if(e1 == 2) {
                    e1 += 2;
                    hitnumC++;
                    cout << "Hit!";
                } else if(e1 == 3) {
                    e1++;
                    hitnumC++;
                    cout << "Hit!";
                }
                isHite1 = true;
            } else if(acoordC == "e2") {
                if(e2 == 0) {
                    e2++;
                    cout << "Miss!";
                } else if(e2 == 2) {
                    e2 += 2;
                    hitnumC++;
                    cout << "Hit!";
                } else if(e2 == 3) {
                    e2++;
                    hitnumC++;
                    cout << "Hit!";
                }
                isHite2 = true;
            } else if(acoordC == "e3") {
                if(e3 == 0) {
                    e3++;
                    cout << "Miss!";
                } else if(e3 == 2) {
                    e3 += 2;
                    hitnumC++;
                    cout << "Hit!";
                } else if(e3 == 3) {
                    e3++;
                    hitnumC++;
                    cout << "Hit!";
                }
                isHite3 = true;
            } else if(acoordC == "e4") {
                if(e4 == 0) {
                    e4++;
                    cout << "Miss!";
                } else if(e4 == 2) {
                    e4 += 2;
                    hitnumC++;
                    cout << "Hit!";
                } else if(e4 == 3) {
                    e4++;
                    hitnumC++;
                    cout << "Hit!";
                }
                isHite4 = true;
            } else if(acoordC == "e5") {
                if(e5 == 0) {
                    e5++;
                    cout << "Miss!";
                } else if(e5 == 2) {
                    e5 += 2;
                    hitnumC++;
                    cout << "Hit!";
                } else if(e5 == 3) {
                    e5++;
                    hitnumC++;
                    cout << "Hit!";
                }
                isHite5 = true;
            }
    
    
    return 0;
}

