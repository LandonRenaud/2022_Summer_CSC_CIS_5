/* 
 * File:   main.cpp
 * Author: Landon Renaud
 * Created on July 31, 2022, 1:25 AM
 * Purpose: verision 6: calculate standard deviation of round average for the records menu, bug fixes
 */

//System Libraries
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <ctime>
#include <cmath>
#include <cstdlib>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants
//Mathematical/Physics/Conversions, Higher dimensioned arrays
const unsigned short COLS = 11;

// ******************************** //
// FUNCTION PROTOTYPES: Lines 29-69 //
// ******************************** //

// prints the menu image
void prntmenu();
// prints instructions
void prntInstruc();

// SETUP FUNCTIONS: lines 34-43
int getDiff(); // gets the difficulty the player chooses
void initboard(unsigned short [][COLS], const unsigned short); // initiates the board with all 0s to prep the game
void initIsHit(bool [][COLS], const unsigned short); // initiates the isHit array as all false to prep the game
void getPshipPos(unsigned short [][COLS], const unsigned short, int); // gets the player's ship positions
void getCPUpos(unsigned short [][COLS], const unsigned short); // gets the cpu ship positions

// function to verify ship placements, error code 1: ship goes off the board, error code 2: ship overlaps another ship, error code 3: invalid direction
int isSPgood(const unsigned short [][COLS], const unsigned short, char, unsigned short, unsigned short, const unsigned short, int&, int&); 
void prntboard(short unsigned [][COLS], const unsigned short); // overloaded function, prints only the player's board, used during the setup phase

// Gameplay functions
void prntboard(short unsigned [][COLS], short unsigned [][COLS], const unsigned short); // overloaded function, prints both boards, used during the game play phase
void playerATK(unsigned short [][COLS], unsigned short&); // gets the player attack and verifies it.

// CPU A.I. Functions
void CPUatkE(unsigned short [][COLS], unsigned short&); // a.i. function for easy mode, attacks at random
void CPUatkN(unsigned short [][COLS], unsigned short&, bool [][COLS]); // a.i. function for normal mode, attacks at random, but doesn't attack the same spot
void CPUatkH(unsigned short [][COLS], const int, unsigned short&, bool [][COLS], int, bool&, int&, int&, int&); // a.i for hard mode, attacks at random until 
                                                                                                                // it scores a hit, then checks in all directions
                                                                                                                // until it gets another hit, and continues in that direction
                                                                                                                // will occasionally cheat and search the player board for a ship
                                                                                                                // and hit it. 
void hitsrch(unsigned short [][COLS], int&, int&, const unsigned short); // the hard mode a.i. ccheat function, searches for a player's ship and hits it

// detect game over
bool isgameovr(unsigned short, unsigned short, bool&, unsigned short [][COLS], unsigned short [][COLS], const unsigned short); //checks ships remaining, returns false if game is still going

// Records Functions
void getPname(const int, unsigned int); // gets the player's name if the player won for the leader board
                                        // stores the winner's name and round count in text files
void getLeader(const int); // gets the leader board from file records
void prntLeader(string [], int [], const int = 10); // prints the leader board and its scorers, is defaulted to 10 entrees, but can go up to 20 entrees
void entrySort(string [], int [], int); // sorts the leader board entrees by the rounds it took them to win
void getWR(unsigned, unsigned, bool); // overloaded function, gets the win rate of the user after a game has ended and updates it with the data from the latest game
int getWR(); // overloaded function, calculates the win rate overall from the file records
void storeRoundNum(vector<unsigned int>, unsigned int); // stores the round num of the current game into the file record
int getRoundAVE(vector<unsigned int>); // calculates the average rounds from the file record of rounds
void getSTDdeviation(vector<unsigned int>, float); // calculates the standard deviation of the average rounds
void recordWipe(); // writes "" to every file in the record aside from the menu and instructions files


// ********************************************** //
// EXCUTUTION BEGINS HERE: main() is lines 80-248 //
// ********************************************** //

int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    srand(static_cast<unsigned short>(time(0)));
    
    //Declare Variables lines 32-70
    char choice;
    int diff = 0; // difficulty variable, 1 = easy, 2 = normal, 3 = hard
    const unsigned short ROWS = 11;
    unsigned short cpuatkn;     // a number to be randomly generated to determine where the CPU will attack 
    
    // variables for record keeping
    unsigned int wincnt = 0,    // tracks the number of player wins for the purpose of win rate calculation
                 gamenum = 0,   // tracks the current game number for the purpose of win rate calculation
                 roundno = 0;   // a variable to track the number of rounds, which will be displayed at the end of the game
    vector<unsigned int> rounds(0); // used for calculating round averages
    float rndave; // stores the round average after its calculated for use in the standard deviation function
    string recCont; // a dummy string to be used to pause the code while the user looks at the records page
    //string plyrN[], plyrR[];  // parallel arrays for 
    
    // game state variables
    string dummy; // a general use storage variable for a cin object to fill, which is used to stall menu interfaces
    bool gamest = true; // game state variable, once game state is false the game will end, 
                        // and the player will be asked if they want to play again
    bool playerW,       // a variable for storing win rate, if the player wins, it equals 1, if the CPU wins, it equals 0
         exit = false;  // a variable to determine whether the program should be stopped or not
    
    // player board variables
    unsigned short pBoard[ROWS][COLS],
                   hitnumP = 0; // tracks the number of hits made by the player, if the number reaches 7, the player wins
    
    // CPU board variables
    unsigned short cBoard[ROWS][COLS],
                   hitnumC = 0; // tracks the number of hits made by the CPU, if the number reaches 7, the CPU wins
    
    // CPU ai variables, if true, the cpu will never attack that space for the rest of the game, for normal and hard difficulty
    bool isHit[ROWS][COLS],
         prevhit; // used in the hard difficulty
    int count, // used in the hard difficulty
            x, 
            y;
    /* 
     * VALUE KEY FOR PLAYER AND COMPUTER BOARD VARIABLES
     * EX: a1
     * a1 = 0, + clear space
     * a1 = 1, O missed shot
     * a1 = 2, # Aircraft Carrier ship tile
     * a1 = 3, # Battleship ship tile
     * a1 = 4, # Cruiser ship tile
     * a1 = 5, # Destroyer ship tile
     * a1 = 6, X hit
     */
    
    // LOOP STARTS HERE: when this loop ends, the program is terminated
    do{
        // resets variables in the case that the player decides to play again
        prntmenu(); // prints menu
        hitnumP = 0;
        hitnumC = 0;
        prevhit = false;
        count = 5;
        roundno = 1;
        
        cout << " Enter Choice: ";
        cin.clear();
        //cin.ignore();
        cin >> choice;
        
        // switch case for menu
        // case 1: runs the game loop
        // case 2: prints instructions
        // case 3: opens the records page
        // case 4: exits the loop and therefore the program
        switch(choice) {
            case '1': {
                // initiallize all board tile values to 0
                initboard(pBoard, ROWS); // for player board
                initboard(cBoard, ROWS); // for CPU board
                initIsHit(isHit, ROWS);  // resets CPU A.I. array, all indexes are set to false
                cout  << "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n";

                do {
                    diff = getDiff();
                } while(diff == 0);

                // setup functions
                getPshipPos(pBoard, ROWS, diff);
                getCPUpos(cBoard, ROWS);

                cout << "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n"
                     << "\nAll ship placements set! \n\n\t\t\t     -=-= GAME  START =-=-\n";

                // GAMEPLAY CYCLE IN THIS LOOP
                do {
                    prntboard(pBoard, cBoard, ROWS);
                    playerATK(cBoard, hitnumP);

                    switch(diff) {
                        case 1: {
                            CPUatkE(pBoard, hitnumC);
                            break;
                        }
                        case 2: {
                            CPUatkN(pBoard, hitnumC, isHit);
                            break;
                        }
                        case 3: {
                            //cout << "x: " << x << endl << "y: " << y << endl;
                            CPUatkH(pBoard, ROWS, hitnumC, isHit, roundno, prevhit, x, y, count);
                            //cout << "x: " << x << endl << "y: " << y << endl;
                            //if(isHit[y][x] == false) cout << "Not working \n";

                            break;
                        }
                    }
                    roundno++;
                    //hitnumP = 28;
                } while(!isgameovr(hitnumP, hitnumC, playerW, pBoard, cBoard, ROWS));

                storeRoundNum(rounds, roundno);
                cout << "\nThe game ended in " << roundno << " rounds.\n";

                // display winrate
                getWR(wincnt, gamenum, playerW);

                if(playerW) {
                    getPname(100, roundno);
                }

                cout << "\nEnter any value to continue: ";
                cin >> dummy;
                
                cout << "\n\n\n\n\n\n\n\n\n";
                
                break;
            } 
            case '2': {
                cout << endl;
                prntInstruc();
                break;
            }
            case '3': {
                
                
                cout  << "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n";
                getLeader(100);
                cout << "\n\n";
                getWR();
                //cout << "working";
                rndave = getRoundAVE(rounds);
                getSTDdeviation(rounds, rndave);
                cout << "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n";
                cout << " Enter any value to continue: ";
                cin >> recCont;
                cout << endl;
                recordWipe();
                
                break;
            }
            case '4': {
                cout << "\n Good Bye!";
                exit = true;
                break;
            }
            default: cout << "\nPlease input a valid option\n\n";
        }
        
    } while(!exit);
    

    //Exit stage right
    return 0;
}

// *********************************** //
//                                     //
//  FUNCTION DECLARATIONS: LINES 256 - //
//                                     //
// *********************************** //


/*
 * Pseudo Code:
 * Open a file for reading: "Menu.txt"
 * while: an entire line is read from the file: {
 *    store the line in a string
 *    output the string
 * }
 */
void prntmenu() {
    fstream menu;
    menu.open("Menu.txt");
    string mnuline;
    while(getline(menu, mnuline)) {
        cout << mnuline << endl;
    }
    
}

/*
 * Pseudo Code:
 * Open a file for reading: "Menu.txt"
 * while: an entire line is read from the file: {
 *    store the line in a string
 *    output the string
 * }
 */
void prntInstruc() {
    fstream instruc;
    instruc.open("Instructions.txt");
    string iline;
    string dummy;
    while(getline(instruc, iline)) {
        cout << iline << endl;
    }
    cout << " Enter any value to Return to menu: ";
    cin >> dummy;
    cout << "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n";
}

/*
 * Pseudo Code:
 * for: every row {
 *    initialize every value in that row as 0
 * }
 */
void initboard(unsigned short board[][COLS], const unsigned short ROWS) {
    for(int n = 0; n < ROWS; n++) {
        for(int a = 0; a < COLS; a++) {
            board[n][a] = 0;
        }
    }
}

/*
 * Pseudo Code:
 * for: every row {
 *    initialize every value in that row as false
 * }
 */
void initIsHit(bool isHit[][COLS], const unsigned short ROWS) {
    for(int n = 0; n < ROWS; n++) {
        for(int a = 0; a < COLS; a++) {
            isHit[n][a] = false;
        }
    }
}

/*
 * Pseudo Code
 * prompt user to input difficulty
 * input: difficulty
 * if: difficulty is not 1 2 or 3 {
 *    output error message
 *    return 0
 * }
 * return difficulty
 */
int getDiff() {
    int diff;
    cout << " Select a Difficulty: \n"
         << " 1: Easy Mode\n 2: Normal Mode\n 3: Hard Mode"
         << "\n\n Difficulty: ";
    cin.clear();
    cin.ignore(1000, '\n');
    cin >> diff;
    if(diff != 1 && diff != 2 && diff != 3) {
        cout << " Error: please input a valid difficulty level\n\n";
        return 0;
    }
    return diff;
}

/*
 * Pseudo Code:
 * if: the input coords are out of range {
 *    error code = 4
 * } else {
 *    convert input coords to int values for processing
 * }
 * check direction:
 * if: in entered direction is 1-4 {
 *    for: count is less than ship length, increment count {
 *       if: coords contain a ship space {
 *          error code = 1
 *       } else {
 *          error code = 0 (no error)
 *       }
 *    }
 * } else error code = 3
 * 
 * return error code
 */
int isSPgood(const unsigned short board[][COLS], const unsigned short ROWS, char xcoord, unsigned short ycoord, unsigned short direc, const unsigned short LENGTH, int& x, int& y) {
    unsigned short ecode;
    // converts tile to a valid input for the 2d array
    if(xcoord < 97 || xcoord > 107 || ycoord > 11 || ycoord < 1) {
        ecode = 4; // invalid coord error
        return ecode;
    } else {
        x = static_cast<int>(xcoord)-97; // subtract one extra for correction (since arrays go from 0 to SIZE-1)
        y = ycoord-1; // subtract one to convert user input to correct array index (since arrays go from 0 to SIZE-1)A
    }
    
    //cout << "x: " << x << endl << "y: " << y << endl;
    if(direc == 1) {
        for(int n = 0; n < LENGTH; n++) {
            //cout << y-(n-1)<< endl;
            if(board[y-n][x] == 0) ecode = 0; // no error
            if((y-n) < 0) ecode = 1; // off board error
            if(board[y-n][x] == 2 || 
               board[y-n][x] == 3 || 
               board[y-n][x] == 4 || 
               board[y-n][x] == 5) ecode = 2;   // ship overlap error
        }
    } else if(direc == 2) {
        for(int n = 1; n <= LENGTH; n++) {
            if(board[y][x+n] == 0) ecode = 0; // no error
            if((x+n) > COLS) ecode = 1; // off board error
            if(board[y][x] == 2 || 
               board[y][x] == 3 || 
               board[y][x] == 4 || 
               board[y][x] == 5) ecode = 2;   // ship overlap error
        }
    } else if(direc == 3) {
        for(int n = 1; n <= LENGTH; n++) {
            if(board[y+n][x] == 0) ecode = 0; // no error
            if((y+n) > ROWS) ecode = 1; // off board error
            if(board[y+n][x] == 2 || 
               board[y+n][x] == 3 || 
               board[y+n][x] == 4 || 
               board[y+n][x] == 5) ecode = 2;   // ship overlap error
        }
    } else if(direc == 4) {
        for(int n = 0; n < LENGTH; n++) {
            if(board[y][x-n] == 0) ecode = 0; // no error
            if((x-n) < 0) ecode = 1; // off board error
            if(board[y][x-n] == 2 || 
               board[y][x-n] == 3 || 
               board[y][x-n] == 4 || 
               board[y][x-n] == 5) ecode = 2;   // ship overlap error
        }
    } else ecode = 3; // invalid direction error
    return ecode;
}


/* 
 * VALUE KEY FOR PLAYER AND COMPUTER BOARD VARIABLES
 * EX: a1
 * a1 = 0, + clear space
 * a1 = 1, O missed shot
 * a1 = 2, # Aircraft Carrier ship tile
 * a1 = 3, # Battleship ship tile
 * a1 = 4, # Cruiser ship tile
 * a1 = 5, # Destroyer ship tile
 * a1 = 6, X hit
 */

/*
 * Pseudo Code:
 * prompt player to input ship position for placing on the board
 * while: ships remain to be placed {
 *    input: ship placement code
 *    function call: isSPgood()
 * 
 *    switch case: {
 *       case destroyer: {
 *          if: destroyer count = 0, output error message
 *          else {
 *             if: error code = 1-4, output respective error message
 *             else: set ship according to placement input, decrement destroyer count
 *          }
 *       }
 *       case battleship: {
 *          if: destroyer count = 0, output error message
 *          else {
 *             if: error code = 1-4, output respective error message
 *             else: set ship according to placement input, decrement battleship count
 *          }
 *       }
 *       case cruiser: {
 *          if: destroyer count = 0, output error message
 *          else {
 *             if: error code = 1-4, output respective error message
 *             else: set ship according to placement input, decrement cruiser count
 *          }
 *       }
 *       case aircraft carrier: {
 *          if: destroyer count = 0, output error message
 *          else {
 *             if: error code = 1-4, output respective error message
 *             else: set ship according to placement input, decrement aircraft carrier count
 *          }
 *       } default: output error message (invalid ship type)
 *    }
 * }
 */
void getPshipPos(unsigned short pBoard[][COLS], const unsigned short ROWS, int diff) {
    // Variables:
    int count;
    char xcoord;
    unsigned short direc;
    char schoice;
    unsigned short dCnt = 3,    // destroyer count
                   bCnt = 1,    // battleship count
                   cCnt = 3,    // cruiser count
                   aCnt = 2,    // aircraft carrier count
                   ycoord,
                   ecode;       // error code variable, equals 0 of no error
    int x, y;
    const unsigned short DLENGTH = 2, // destroyer length
                         BLENGTH = 5, // battleship length
                         CLENGTH = 3, // cruiser length
                         ALENGTH = 4; // aircraft carrier length
    unsigned short length; // a variable to be passed to the ship position checking function, describes the length of a ship for validation purposes
    
    cout << "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n"
         << "Difficulty set to: " << ((diff == '1')? "Easy":((diff == '2')? "Normal":"Hard"));
    cout << "\n\nPlace your ships on the board: "
         << "\nInput ship, then coordinate, then direction:" 
         << "\n     Example input: B a1 3\n";
    
    while(dCnt > 0 || bCnt > 0 || cCnt > 0 || aCnt > 0) {
        if(count > 100) exit(1); // terminates the program if an error occurs in the i/o buffer
        
        cout << "\n\nAir Craft Carriers (4 Long): " << aCnt << endl
             << "Battleships (5 Long):        " << bCnt << endl
             << "Cruisers (3 Long):           " << cCnt << endl
             << "Destroyers (2 Long):         " << dCnt << endl << endl;
        prntboard(pBoard, ROWS);
        // SHIP PLACEMENT BEGINS HERE:
        cin.clear();
        cin.ignore(1000, '\n');
        cout << "\nPlace ship: \n";
        
        cin >> schoice >> xcoord >> ycoord >> direc;
        //cout << xcoord << " " << ycoord;
        /*
         * Pseudo code:
         * if: ship goes off board, output "error";
         * else if: ship already exists where new ship will be, output "error";
         * else: place ship in spot;
         */
        switch(schoice) {
            case 'd':
            case 'D': {
                if(dCnt == 0) cout << "Error, you have no destroyers left to place.";
                else {
                    length = DLENGTH;
                    ecode = isSPgood(pBoard, ROWS, xcoord, ycoord, direc, length, x, y);
                    xcoord = x;
                    ycoord = y;
                    //cout << "awerfaefref " << ecode << "  awefawefawefr";
                    if(ecode == 1) {
                        cout << "Error: ship goes off the board";
                    } else if(ecode == 2) {
                        cout << "Error: ship overlaps a preexisting ship";
                    } else if(ecode == 3) {
                        cout << "Error: invalid direction";
                    } else if(ecode == 4) {
                        cout << "Error, please input a valid coordinate";
                    } else { // if there is an error, gives respective error message, else sets the ship in the coords provided
                        if(direc == 1) {
                            for(int n = 0; n < length; n++) {
                                pBoard[ycoord-n][xcoord] = 5; 
                            }
                        } else if(direc == 2) {
                            for(int n = 0; n < length; n++) {
                                pBoard[ycoord][xcoord+n] = 5; 
                            }
                        } else if(direc == 3) {
                            for(int n = 0; n < length; n++) {
                                pBoard[ycoord+n][xcoord] = 5; 
                            }
                        } else if(direc == 4) {
                            for(int n = 0; n < length; n++) {
                                pBoard[ycoord][xcoord-n] = 5; 
                            }
                        }
                        dCnt--;
                    }
                    
                }
                break;
            }
            case 'b':
            case 'B': {
                if(bCnt == 0) cout << "Error, you have no battleships left to place.";
                else {
                    length = BLENGTH;
                    ecode = isSPgood(pBoard, ROWS, xcoord, ycoord, direc, length, x, y);
                    xcoord = x;
                    ycoord = y;
                    //cout << "awerfaefref " << ecode << "  awefawefawefr";
                    if(ecode == 1) {
                        cout << "Error: ship goes off the board";
                    } else if(ecode == 2) {
                        cout << "Error: ship overlaps a preexisting ship";
                    } else if(ecode == 3) {
                        cout << "Error: invalid direction";
                    } else if(ecode == 4) {
                        cout << "Error, please input a valid coordinate";
                    } else { // if there is an error, gives respective error message, else sets the ship in the coords provided
                        if(direc == 1) {
                            for(int n = 0; n < length; n++) {
                                pBoard[ycoord-n][xcoord] = 3; 
                            }
                        } else if(direc == 2) {
                            for(int n = 0; n < length; n++) {
                                pBoard[ycoord][xcoord+n] = 3; 
                            }
                        } else if(direc == 3) {
                            for(int n = 0; n < length; n++) {
                                pBoard[ycoord+n][xcoord] = 3; 
                            }
                        } else if(direc == 4) {
                            for(int n = 0; n < length; n++) {
                                pBoard[ycoord][xcoord-n] = 3; 
                            }
                        }
                        bCnt--;
                    }
                }
                break;
            }
            case 'c':
            case 'C': {
                if(cCnt == 0) cout << "Error, you have no cruisers left to place.";
                else {
                    length = CLENGTH;
                    ecode = isSPgood(pBoard, ROWS, xcoord, ycoord, direc, length, x ,y);
                    xcoord = x;
                    ycoord = y;
                    
                    if(ecode == 1) {
                        cout << "Error: ship goes off the board";
                    } else if(ecode == 2) {
                        cout << "Error: ship overlaps a preexisting ship";
                    } else if(ecode == 3) {
                        cout << "Error: invalid direction";
                    } else if(ecode == 4) {
                        cout << "Error, please input a valid coordinate";
                    } else { // if there is an error, gives respective error message, else sets the ship in the coords provided
                        if(direc == 1) {
                            for(int n = 0; n < length; n++) {
                                pBoard[ycoord-n][xcoord] = 4; 
                            }
                        } else if(direc == 2) {
                            for(int n = 0; n < length; n++) {
                                pBoard[ycoord][xcoord+n] = 4; 
                            }
                        } else if(direc == 3) {
                            for(int n = 0; n < length; n++) {
                                pBoard[ycoord+n][xcoord] = 4; 
                            }
                        } else if(direc == 4) {
                            for(int n = 0; n < length; n++) {
                                pBoard[ycoord][xcoord-n] = 4; 
                            }
                        }
                        cCnt--;
                    }
                }
                break;
            }
            case 'a':
            case 'A': {
                if(aCnt == 0) cout << "Error, you have no aircraft carriers left to place.";
                else {
                    length = ALENGTH;
                    ecode = isSPgood(pBoard, ROWS, xcoord, ycoord, direc, length, x, y);
                    xcoord = x;
                    ycoord = y;
                    
                    if(ecode == 1) {
                        cout << "Error: ship goes off the board";
                    } else if(ecode == 2) {
                        cout << "Error: ship overlaps a preexisting ship";
                    } else if(ecode == 3) {
                        cout << "Error: invalid direction";
                    } else if(ecode == 4) {
                        cout << "Error, please input a valid coordinate";
                    } else { // if there is an error, gives respective error message, else sets the ship in the coords provided
                        if(direc == 1) {
                            for(int n = 0; n < length; n++) {
                                pBoard[ycoord-n][xcoord] = 2; 
                            }
                        } else if(direc == 2) {
                            for(int n = 0; n < length; n++) {
                                pBoard[ycoord][xcoord+n] = 2; 
                            }
                        } else if(direc == 3) {
                            for(int n = 0; n < length; n++) {
                                pBoard[ycoord+n][xcoord] = 2; 
                            }
                        } else if(direc == 4) {
                            for(int n = 0; n < length; n++) {
                                pBoard[ycoord][xcoord-n] = 2; 
                            }
                        }
                        aCnt--;
                    }
                }
                break;
            }
            default: cout << "please input a valid ship.";
        }
        
        count++;
    }
}

/*
 * While: there are still ships left to be placed {
 *    randomly generate 4 values:
 *    1. ship choice: range 0-3, add 2
 *    2. direction: range 0-3, add 1
 *    3. x coordinate: range 0-10
 *    4. y coordinate: range 0-10
 *    
 *    function call: isSPgood()   
 * 
 *    switch case: {
 *       case 5 (destroyer): {
 *          if: destroyer count = 0, restart loop
 *          else {
 *             if: error code = 1-4, restart loop
 *             else: set ship according to placement input, decrement destroyer count
 *          }
 *       }
 *       case 4 (cruiser): {
 *          if: destroyer count = 0, restart loop
 *          else {
 *             if: error code = 1-4, restart loop
 *             else: set ship according to placement input, decrement cruiser count
 *          }
 *       }
 *       case 3 (battleship): {
 *          if: destroyer count = 0, restart loop
 *          else {
 *             if: error code = 1-4, restart loop
 *             else: set ship according to placement input, decrement battleship count
 *          }
 *       }
 *       case 2 (aircraft carrier): {
 *          if: destroyer count = 0, restart loop
 *          else {
 *             if: error code = 1-4, restart loop
 *             else: set ship according to placement input, decrement aircraft carrier count
 *          }
 *       }
 *    }
 * }
 */
void getCPUpos(unsigned short cBoard[][COLS], const unsigned short ROWS) {
    // Variables:
    char xcoord;
    unsigned short direc;
    unsigned short schoice;
    unsigned short dCnt = 4,    // destroyer count
                   bCnt = 2,    // battleship count
                   cCnt = 3,    // cruiser count
                   aCnt = 2,    // aircraft carrier count
                   ycoord,
                   ecode;       // error code variable, equals 0 of no error
    int x, y;
    const unsigned short DLENGTH = 2, // destroyer length
                         BLENGTH = 5, // battleship length
                         CLENGTH = 3, // cruiser length
                         ALENGTH = 4; // aircraft carrier length
    unsigned short length; // a variable to be passed to the ship position checking function, describes the length of a ship for validation purposes
    
    while(dCnt > 0 || bCnt > 0 || cCnt > 0 || aCnt > 0) {
        //cout << "working\n";
        schoice = (rand()%4)+2;
        direc = (rand()%4)+1;
        xcoord = static_cast<char>((rand()%11)+97);
        ycoord = (rand()%11)+1;
        
        switch(schoice) {
            case 5: { // destroyer
                if(dCnt != 0) {
                    length = DLENGTH;
                    ecode = isSPgood(cBoard, ROWS, xcoord, ycoord, direc, length, x, y);
                    //cout << ecode << endl;
                    xcoord = x;
                    ycoord = y;
                    //cout << "awerfaefref " << ecode << "  awefawefawefr";
                    if(ecode == 0) { // if there is an error, don't output a message, but restart the loop, until a valid position is found
                        if(direc == 1) {
                            for(int n = 0; n < length; n++) {
                                cBoard[ycoord-n][xcoord] = 5; 
                            }
                        } else if(direc == 2) {
                            for(int n = 0; n < length; n++) {
                                cBoard[ycoord][xcoord+n] = 5; 
                            }
                        } else if(direc == 3) {
                            for(int n = 0; n < length; n++) {
                                cBoard[ycoord+n][xcoord] = 5; 
                            }
                        } else if(direc == 4) {
                            for(int n = 0; n < length; n++) {
                                cBoard[ycoord][xcoord-n] = 5; 
                            }
                        }
                        dCnt--;
                    }
                    
                }
                break;
            }
            case 3: { // battleship
                if(bCnt != 0) {
                    length = BLENGTH;
                    ecode = isSPgood(cBoard, ROWS, xcoord, ycoord, direc, length, x, y);
                    //cout << ecode << endl;
                    xcoord = x;
                    ycoord = y;
                    //cout << "awerfaefref " << ecode << "  awefawefawefr";
                    if(ecode == 0) { // if there is an error, don't output a message, but restart the loop, until a valid position is found
                        if(direc == 1) {
                            for(int n = 0; n < length; n++) {
                                cBoard[ycoord-n][xcoord] = 3; 
                            }
                        } else if(direc == 2) {
                            for(int n = 0; n < length; n++) {
                                cBoard[ycoord][xcoord+n] = 3; 
                            }
                        } else if(direc == 3) {
                            for(int n = 0; n < length; n++) {
                                cBoard[ycoord+n][xcoord] = 3; 
                            }
                        } else if(direc == 4) {
                            for(int n = 0; n < length; n++) {
                                cBoard[ycoord][xcoord-n] = 3; 
                            }
                        }
                        bCnt--;
                    }
                }
                break;
            }
            case 4: { // cruiser
                if(cCnt != 0) {
                    length = CLENGTH;
                    ecode = isSPgood(cBoard, ROWS, xcoord, ycoord, direc, length, x ,y);
                    //cout << ecode << endl;
                    xcoord = x;
                    ycoord = y;
                    
                    if(ecode == 0) { // if there is an error, don't output a message, but restart the loop, until a valid position is found
                        if(direc == 1) {
                            for(int n = 0; n < length; n++) {
                                cBoard[ycoord-n][xcoord] = 4; 
                            }
                        } else if(direc == 2) {
                            for(int n = 0; n < length; n++) {
                                cBoard[ycoord][xcoord+n] = 4; 
                            }
                        } else if(direc == 3) {
                            for(int n = 0; n < length; n++) {
                                cBoard[ycoord+n][xcoord] = 4; 
                            }
                        } else if(direc == 4) {
                            for(int n = 0; n < length; n++) {
                                cBoard[ycoord][xcoord-n] = 4; 
                            }
                        }
                        cCnt--;
                    }
                }
                break;
            }
            case 2: { // aircraft carrier
                if(aCnt != 0) {
                    length = ALENGTH;
                    ecode = isSPgood(cBoard, ROWS, xcoord, ycoord, direc, length, x, y);
                    // << ecode << endl;
                    xcoord = x;
                    ycoord = y;
                    
                    if(ecode == 0) { // if there is an error, don't output a message, but restart the loop, until a valid position is found
                        if(direc == 1) {
                            for(int n = 0; n < length; n++) {
                                cBoard[ycoord-n][xcoord] = 2; 
                            }
                        } else if(direc == 2) {
                            for(int n = 0; n < length; n++) {
                                cBoard[ycoord][xcoord+n] = 2; 
                            }
                        } else if(direc == 3) {
                            for(int n = 0; n < length; n++) {
                                cBoard[ycoord+n][xcoord] = 2; 
                            }
                        } else if(direc == 4) {
                            for(int n = 0; n < length; n++) {
                                cBoard[ycoord][xcoord-n] = 2; 
                            }
                        }
                        aCnt--;
                    }
                }
                break;
            }
        }
    }
}

// only prints the player's board
void prntboard(unsigned short pBoard[][COLS], const unsigned short ROWS) {
    char tile; // to be used with ascii values to print certain characters to make the board less confusing compared to
               // the board from the versions of battleship in project 1
    
    cout << "\t      A B C D E F G H I J K\n\t     - - - - - - - - - - - -\n";
    for(int n = 0; n < ROWS; n++) {
        cout << "\t" << setw(3) << n+1 << " |";
        for(int a = 0; a < COLS; a++) {
            if(pBoard[n][a] == 1) {
                tile = 'O';
            } else if(pBoard[n][a] == 2 || pBoard[n][a] == 3 || pBoard[n][a] == 4 || pBoard[n][a] == 5) {
                tile = '#';
            } else if(pBoard[n][a] == 6) {
                tile = 'X';
            } else tile = '+';
            cout << " " << tile;
        }
        cout << " |\n";
    }
    cout << "\t     - - - - - - - - - - - -\n";
}

// prints both game boards
void prntboard(unsigned short pBoard[][COLS], unsigned short cBoard[][COLS], const unsigned short ROWS) {
    char ptile,
         ctile;   
    
    cout << "\n\n      A B C D E F G H I J K\t\t\t      A B C D E F G H I J K\n"
         << "     - - - - - - - - - - - -\t\t\t     - - - - - - - - - - - -\n";
    for(int n = 0; n < ROWS; n++) {
        cout << setw(3) << n+1 << " |";
        for(int a = 0; a < COLS; a++) {
            if(pBoard[n][a] == 1) {
                ptile = 'O';
            } else if(pBoard[n][a] == 2 || pBoard[n][a] == 3 || pBoard[n][a] == 4 || pBoard[n][a] == 5) {
                ptile = '#';
            } else if(pBoard[n][a] == 6) {
                ptile = 'X';
            } else ptile = '+';
            cout << " " << ptile;
        }
        cout << " |\t\t\t";
        cout << setw(3) << n+1 << " |";
        for(int a = 0; a < COLS; a++) {
            if(cBoard[n][a] == 1) {
                ctile = 'O';
            } else if(cBoard[n][a] == 2 || cBoard[n][a] == 3 || cBoard[n][a] == 4 || cBoard[n][a] == 5) {
                ctile = '+';
            } else if(cBoard[n][a] == 6) {
                ctile = 'X';
            } else ctile = '+';
            cout << " " << ctile;
        }
        cout << " |\n";
    }
    cout << "     - - - - - - - - - - - -\t\t\t     - - - - - - - - - - - -\n";
}

/*
 * Pseudo Code:
 * Prompt the user to input a coordinate for an attack
 * Input: player attack coordinate
 * 
 * convert first part from char to int (values 0-10)
 * subtract 1 from second part (to prepare for processing in the arrays)
 * 
 * if: the x coord is not within 0-10 or the y coord is not within 0-10 {
 *    output error message
 * } else {
 *    if: the coordinate has a value of 0 {
 *       set the coordinate to a value of 1
 *       output: "Miss!"
 *    } else if: if the coordinate has a value of 2,3,4,5 {
 *       set the coordinate to a value of 6
 *       output: "Hit!"
 *       increment player hit count
 *    }
 * }
 */
void playerATK(unsigned short cBoard[][COLS], unsigned short& hitnumP) {
    char xcoord;
    unsigned short ycoord;
    int x, y;
    cout << "Input Coordinates for an Attack (Ex: a1): ";
    cin.clear();
    cin.ignore(1000, '\n');
    cin >> xcoord >> ycoord;
    
    x = static_cast<int>(xcoord)-97; // subtract one extra for correction (since arrays go from 0 to SIZE-1)
    y = ycoord-1; // subtract one to convert user input to correct array index (since arrays go from 0 to SIZE-1)
    
    if(x < 0 || x > 11 || y < 0 || y > 11) {
        cout << "Error: Please input a Valid Attack Coordinate";
    } else {
        if(cBoard[y][x] == 0) {
            cBoard[y][x] = 1;
            cout << "Miss!";
        } else if(cBoard[y][x] == 2 || cBoard[y][x] == 3 ||
                  cBoard[y][x] == 4 || cBoard[y][x] == 5) {
            cBoard[y][x] = 6;
            hitnumP++;
            cout << "Hit!";
        }
    }
}

// the A.I. randomly guesses coordinates
/*
 * Pseudo Code:
 * randomly generate 2 values:
 * 1. x coord: range 0-10
 * 2. y coord: range 0-10
 * output the coords the CPU attacked
 * 
 * if: the coordinate has a value of 0 {
 *    set the coordinate to a value of 1
 *    output: "Miss!"
 * } else if: if the coordinate has a value of 2,3,4,5 {
 *    set the coordinate to a value of 6
 *    output: "Hit!"
 *    increment cpu hit count
 * }
 */
void CPUatkE(unsigned short pBoard[][COLS], unsigned short& hitnumC) {
    unsigned short x = (rand()%11),
                   y = (rand()%11);
    cout << "\n\nThe CPU attacked " << static_cast<char>(x+97) << y+1 <<"!\n";
    
    if(pBoard[y][x] == 0) {
        pBoard[y][x] = 1;
        cout << "Miss!";
    } else if(pBoard[y][x] == 2 || pBoard[y][x] == 3 ||
            pBoard[y][x] == 4 || pBoard[y][x] == 5) {
        pBoard[y][x] = 6;
        cout << "Hit!";
        hitnumC++;
    }
}

// the A.I. randomly guesses coordinates, and marks them, so that coordinate will not be guessed again
/*
 * Pseudo Code:
 * do {
 *    randomly generate 2 values:
 *    1. x coord: range 0-10
 *    2. y coord: range 0-10
 *    output the coords the CPU attacked
 * 
 *    if: the selected coordinate has not yet been attacked {
 *       if: the coordinate has a value of 0 {
 *          set the coordinate to a value of 1
 *          output: "Miss!"
 *       } else if: if the coordinate has a value of 2,3,4,5 {
 *          set the coordinate to a value of 6
 *          output: "Hit!"
 *          increment CPU hit count
 *       }
 *       mark coordinate as found
 *    }
 * } while: an attack coordinate has not been chosen
 */
void CPUatkN(unsigned short pBoard[][COLS], unsigned short& hitnumC, bool isHit[][COLS]) {
    bool found = false;
    do {
        unsigned short x = (rand()%11),
                       y = (rand()%11);
        //cout << "working\n";
        //cout << "x: " << x << endl << "y: " << y << endl;
        if(isHit[y][x] == false) {
            cout << "\n\nThe CPU attacked " << static_cast<char>(x+97) << y+1 <<"!\n";
            if(pBoard[y][x] == 0) {
                pBoard[y][x] = 1;
                cout << "Miss!";
            } else if(pBoard[y][x] == 2 || pBoard[y][x] == 3 ||
                    pBoard[y][x] == 4 || pBoard[y][x] == 5) {
                pBoard[y][x] = 6;
                cout << "Hit!";
                hitnumC++;
            }
            isHit[y][x] = true;
            found = true;
        }
    } while(!found);
}

// the A.I. will randomly guess a coordinate until it scores a hit, then it will check the surrounding coordinates, if it finds another hit, it will
// continue to attack in that direction
/*
 * Pseudo Code:
 * do {
 *    if: the A.I. has previously scored a hit {
 *       switch case: count {
 *          case: 1 {
 *             check the coordinate above
 *             if: check coordinate is hit {
 *                set coord value to 6
 *                output: "Hit!"
 *                increment CPU hit count
 *             } else {
 *                set coord value to 1
 *                output: "Miss!"
 *                increment count
 *             }
 *             mark coordinate as hit
 *          }
 *          case: 2 {
 *             check the coordinate to the right
 *             if: check coordinate is hit {
 *                set coord value to 6
 *                output: "Hit!"
 *                increment CPU hit count
 *             } else {
 *                set coord value to 1
 *                output: "Miss!"
 *                increment count
 *             }
 *             mark coordinate as hit
 *          }
 *          case: 3 {
 *             check the coordinate below
 *             if: check coordinate is hit {
 *                set coord value to 6
 *                output: "Hit!"
 *                increment CPU hit count
 *             } else {
 *                set coord value to 1
 *                output: "Miss!"
 *                increment count
 *             }
 *             mark coordinate as hit
 *          }
 *          case: 4 {
 *             check the coordinate to the left
 *             if: check coordinate is hit {
 *                set coord value to 6
 *                output: "Hit!"
 *                increment CPU hit count
 *             } else {
 *                set coord value to 1
 *                output: "Miss!"
 *                increment count
 *             }
 *             mark coordinate as hit
 *          } default: set status of previously hit to false, count = 5
 *       }
 *       
 *    } else if: the current round is a multiple of 6 (every 6 rounds) {
 *       function call: hitsrch()
 *       increment CPU hit count
 *       output CPU atk coords
 *       output: "Hit!"
 *       mark the coords as hit
 * 
 *    } else {
 *       randomly generate 2 values:
 *       1. x coord: range 0-10
 *       2. y coord: range 0-10
 *       output the coords the CPU attacked
 * 
 *       if: the selected coordinate has not yet been attacked {
 *          if: the coordinate has a value of 0 {
 *             set the coordinate to a value of 1
 *             output: "Miss!"
 *          } else if: if the coordinate has a value of 2,3,4,5 {
 *             set the coordinate to a value of 6
 *             output: "Hit!"
 *             increment CPU hit count
 *          }
 *          set the count to 1
 *          mark coordinate as found
 *       }
 *    }
 * } while: an attack coordinate has not been chosen
 */
void CPUatkH(unsigned short pBoard[][COLS], const int ROWS, unsigned short& hitnumC, bool isHit[][COLS], int roundno, bool& prevhit, int& prevx, int& prevy, int& count) {
    int x = prevx,
        y = prevy;
    bool found = false;
    
    do {
       
        if(prevhit || count < 5) {
            //cout << "direction: " << count << endl;
            //cout << "working\n";
            switch(count) {
                case 1: {
                    y--;
                    //cout << "x: " << x << endl << "y: " << y << endl;
                    
                    if(isHit[y][x] == false) {
                        if(y > 0) {
                            cout << "\n\nThe CPU attacked " << static_cast<char>(x+97) << y+1 <<"!\n";
                            
                                if(pBoard[y][x] == 0) {
                                    pBoard[y][x] = 1;
                                    cout << "Miss!";
                                    count++;
                                    y++;

                                } else if(pBoard[y][x] == 2 || pBoard[y][x] == 3 ||
                                          pBoard[y][x] == 4 || pBoard[y][x] == 5) {
                                    pBoard[y][x] = 6;
                                    cout << "Hit!";
                                    hitnumC++;
                                    prevhit = true;
                                }
                                found = true;
                            

                        } else if(y == 0) {
                            cout << "\n\nThe CPU attacked " << static_cast<char>(x+97) << y+1 <<"!\n";
                            if(pBoard[y][x] == 0) {
                                pBoard[y][x] = 1;
                                cout << "Miss!";

                            } else if(pBoard[y][x] == 2 || pBoard[y][x] == 3 ||
                                      pBoard[y][x] == 4 || pBoard[y][x] == 5) {
                                pBoard[y][x] = 6;
                                cout << "Hit!";
                                hitnumC++;
                                y--;
                            }

                            count = 5;
                            found = true;

                        }
                        isHit[y][x] = true;
                        
                    } else {
                        count = 5;
                        prevhit = false;
                    }
                    break;
                }
                case 2: {
                    x++;
                    //cout << "x: " << x << endl << "y: " << y << endl;
                    if(isHit[y][x] == false) {
                        if(x < 10) {
                            cout << "\n\nThe CPU attacked " << static_cast<char>(x+97) << y+1 <<"!\n";
                            if(pBoard[y][x] == 0) {
                                pBoard[y][x] = 1;
                                cout << "Miss!";
                                count++;
                                x--;

                            } else if(pBoard[y][x] == 2 || pBoard[y][x] == 3 ||
                                      pBoard[y][x] == 4 || pBoard[y][x] == 5) {
                                pBoard[y][x] = 6;
                                cout << "Hit!";
                                hitnumC++;
                                prevhit = true;
                            }

                            found = true;

                        } else if(x == 10) {
                            cout << "\n\nThe CPU attacked " << static_cast<char>(x+97) << y+1 <<"!\n";
                            if(pBoard[y][x] == 0) {
                                pBoard[y][x] = 1;
                                cout << "Miss!";

                            } else if(pBoard[y][x] == 2 || pBoard[y][x] == 3 ||
                                      pBoard[y][x] == 4 || pBoard[y][x] == 5) {
                                pBoard[y][x] = 6;
                                cout << "Hit!";
                                hitnumC++;
                            }

                            count = 5;
                            found = true;

                        }
                        isHit[y][x] = true;
                        
                    } else {
                        count = 5;
                        prevhit = false;
                    }
                    
                    break;
                }
                case 3: {
                    y++;
                    //cout << "x: " << x << endl << "y: " << y << endl;
                    if(isHit[y][x] == false) {
                        if(y < 10) {
                            cout << "\n\nThe CPU attacked " << static_cast<char>(x+97) << y+1 <<"!\n";
                            if(pBoard[y][x] == 0) {
                                pBoard[y][x] = 1;
                                cout << "Miss!";
                                count++;
                                y--;

                            } else if(pBoard[y][x] == 2 || pBoard[y][x] == 3 ||
                                      pBoard[y][x] == 4 || pBoard[y][x] == 5) {
                                pBoard[y][x] = 6;
                                cout << "Hit!";
                                hitnumC++;
                                prevhit = true;
                            }

                            found = true;

                        } else if(y == 10) {
                            cout << "\n\nThe CPU attacked " << static_cast<char>(x+97) << y+1 <<"!\n";
                            if(pBoard[y][x] == 0) {
                                pBoard[y][x] = 1;
                                cout << "Miss!";


                            } else if(pBoard[y][x] == 2 || pBoard[y][x] == 3 ||
                                      pBoard[y][x] == 4 || pBoard[y][x] == 5) {
                                pBoard[y][x] = 6;
                                cout << "Hit!";
                                hitnumC++;
                            }

                            count = 5;
                            found = true;

                        } 
                        isHit[y][x] = true;
                        
                    } else {
                        
                        count = 5;
                        prevhit = false;
                    }
                    break;
                }
                case 4: {
                    x--;
                    //cout << "x: " << x << endl << "y: " << y << endl;
                    if(isHit[y][x] == false) {
                        if(x > 0) {
                            cout << "\n\nThe CPU attacked " << static_cast<char>(x+97) << y+1 <<"!\n";
                            if(pBoard[y][x] == 0) {
                                pBoard[y][x] = 1;
                                cout << "Miss!";
                                count++;
                                x++;

                            } else if(pBoard[y][x] == 2 || pBoard[y][x] == 3 ||
                                      pBoard[y][x] == 4 || pBoard[y][x] == 5) {
                                pBoard[y][x] = 6;
                                cout << "Hit!";
                                hitnumC++;
                                prevhit = true;
                            }

                            found = true;

                        } else if(x == 0) {
                            cout << "\n\nThe CPU attacked " << static_cast<char>(x+97) << y+1 <<"!\n";
                            if(pBoard[y][x] == 0) {
                                pBoard[y][x] = 1;
                                cout << "Miss!";

                            } else if(pBoard[y][x] == 2 || pBoard[y][x] == 3 ||
                                      pBoard[y][x] == 4 || pBoard[y][x] == 5) {
                                pBoard[y][x] = 6;
                                cout << "Hit!";
                                hitnumC++;
                            }

                            count = 5;
                            found = true;

                        } 
                        isHit[y][x] = true;
                        
                    } else {
                        
                        count = 5;
                        prevhit = false;
                    }
                    break;
                }
                default: {
                    count = 5;
                    prevhit = false;
                }
            }
            //isHit[y][x] = true;
            prevx = x;
            prevy = y;
            
        } else if((roundno%6 == 0) && (roundno != 0)) {
            //cout << "working";
            hitsrch(pBoard, x, y, ROWS);
            cout << "\n\nThe CPU attacked " << static_cast<char>(x+97) << y+1 <<"!\n";
            cout << "Hit!";
            isHit[x][y] = true;
            found = true;
            hitnumC++;
            
        } else {
            //cout << "working rand\n";
            unsigned short x = (rand()%11),
                           y = (rand()%11);
            //cout << "x: " << x << endl << "y: " << y << endl;
            //cout << "x: " << x << endl << "y: " << y << endl;
            if(isHit[y][x] == false) {
                
                cout << "\n\nThe CPU attacked " << static_cast<char>(x+97) << y+1 <<"!\n";
                if(pBoard[y][x] == 0) {
                    pBoard[y][x] = 1;
                    cout << "Miss!";
                    
                } else if(pBoard[y][x] == 2 || pBoard[y][x] == 3 ||
                          pBoard[y][x] == 4 || pBoard[y][x] == 5) {
                    pBoard[y][x] = 6;
                    cout << "Hit!";
                    hitnumC++;
                    prevhit = true;
                    count = 1;
                    
                    prevx = x;
                    prevy = y;
                }

                isHit[y][x] = true;
                found = true;
            }
        }
         
    } while(!found);
}

// Uses linear Search to search for a 2, 3, 4, or 5 in the player board array, sets the indexes to the x and y values 
// (in order to display where the CPU attacks)
void hitsrch(unsigned short pBoard[][COLS], int& x, int& y, const unsigned short ROWS) {
    for(int n = 0; n < ROWS; n++) {
        for(int a = 0; a < COLS; a++) {
            if(pBoard[n][a] == 2 || pBoard[n][a] == 3 ||
               pBoard[n][a] == 4 || pBoard[n][a] == 5) {
                pBoard[n][a] = 6;
                
                x = a;
                y = n;
                a = COLS;
                n = ROWS;
            }
        }
    }
}

// checks the hit counts of both sides, if both sides win, outputs a tie message, if one side wins, outputs a message that that side has won. In the case
// that the player wins, sets a boolean to true for player win. the boolean will be used in the getWR() function for score keeping purposes. 
// the boolean will also be used in the getPname() function, also for score keeping purposes
bool isgameovr(unsigned short hitnumP, unsigned short hitnumC, bool& playerW, unsigned short pBoard[][COLS], unsigned short cBoard[][COLS], const unsigned short ROWS) {
    if(hitnumP == 28 && hitnumC != 28) {
        prntboard(pBoard, cBoard, ROWS);
        cout << "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n"
             << "\n\nGAME OVER\nCongratulations, You Win! You Have Sunken All of the Enemy's Ships\n";
        playerW = true;
        
        return true;
        
    } else if(hitnumC == 28 && hitnumP != 28) {
        prntboard(pBoard, cBoard, ROWS);
        cout << "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n"
             << "\n\nGAME OVER\nYou Lose! All Your Ships Have Been Sunken";
        
        return true;
        
    } else if(hitnumC == 28 && hitnumP == 28) {
        prntboard(pBoard, cBoard, ROWS);
        cout << "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n"
             << "\n\nGAME OVER\nBoth Sides Have Destroyed Each Other! It's A Tie!\n";
        
        return true;
        
    } else return false;
}

/*
 * Pseudo Code:
 * create one dimensional parallel arrays:
 * player names: array of strings
 * player rounds: array of integers
 * 
 * open the player names file for reading
 * while: a name is read from the file {
 *    read the name into the player name array
 *    increment the index
 * }
 * close the file
 * 
 * open the player rounds file for reading
 * for: count is less than or equal to the index {
 *    read the player round into the player rounds array
 * }
 * close the file
 * 
 * prompt the user to enter a username (limit 10 characters, no spaces)
 * input: player's name
 * store player's name into the next slot in the string array
 * store the round number of the game into the next slot in the int array
 * 
 * open the player names file for writing
 * for: count is less than or equal to the current number of names stored in the array {
 *    store the contents of the array at array index = count into the file
 * }
 * close the file
 * 
 * open the player rounds file for writing
 * for: count is less than or equal to the current round entrees of names stored in the array {
 *    store the contents of the array at array index = count into the file
 * }
 * close the file
 * 
 */
void getPname(const int LIMIT, unsigned int roundno) {
    string plyrN[LIMIT]; // an array of user names from players who've won
    int plyrR[LIMIT];    // an array of round counts for players who've won, the positions in the array correspond to
                         // the same positions in the name array
    static int index;
    
    ofstream pnIN;
    ifstream pnOUT;
    ofstream prIN;
    ifstream prOUT;
    
    // fills the arrays with previous entrees
    index = 0;
    pnOUT.open("Playernames.txt");
    while(pnOUT >> plyrN[index]) {
        index++;
    }
    pnOUT.close();
    
    prOUT.open("PlayerRounds.txt");
    for(int n = 0; n <= index; n++) {
        prOUT >> plyrR[n];
    }
    prOUT.close();
    
    // obtains the new entrees
    cout << "Enter Username (No spaces, 10 Characters max): ";
    cin >> plyrN[index];
    plyrR[index] = roundno; 
    
    index++;
    // Replaces the file data with the new data
    pnIN.open("Playernames.txt");
    for(int n = 0; n < index; n++) {
        pnIN << plyrN[n] << " ";
    }
    pnIN.close();
    
    prIN.open("PlayerRounds.txt");
    for(int n = 0; n < index; n++) {
        prIN << plyrR[n] << " ";
    }
    prIN.close();
}

/*
 * Pseudo Code:
 * create one dimensional parallel arrays:
 * player names: array of strings
 * player rounds: array of integers
 * 
 * 
 * initialize the string array at all indexes with "--- "
 * initialize the int array at all indexes with 0
 * 
 * open the player names file for reading
 * while: a name is read from the file {
 *    read the name into the player name array
 *    increment the index
 * }
 * close the file
 * 
 * open the player rounds file for reading
 * for: count is less than or equal to the index {
 *    read the player round into the player rounds array
 * }
 * close the file
 * 
 * function call: entrySort()
 * 
 * if: there are more than 10 entrees in the array, but less than 20 {
 *    function call: prntLeader(), include a parameter for size, which will be the number of entrees
 * } else: function call: prntLeader(), no leader board size parameter, defaulted to 10
 * 
 */
void getLeader(const int LIMIT) {
    string plyrN[LIMIT]; // an array of user names from players who've won
    int plyrR[LIMIT];    // an array of round counts for players who've won, the positions in the array correspond to
                         // the same positions in the name array
    int entrees = 0;
    
    for(int n = 0; n < LIMIT; n++) {
        plyrN[n] = "--- ";
        plyrR[n] = 0;
    }
    
    ofstream pnIN;
    ifstream pnOUT;
    ofstream prIN;
    ifstream prOUT;
    
    // fills the arrays with previous entrees
    entrees = 0;
    pnOUT.open("Playernames.txt");
    while(pnOUT >> plyrN[entrees]) {
        entrees++;
        //cout << "entrees:" << entrees << endl;
    }
    pnOUT.close();

    prOUT.open("PlayerRounds.txt");
    for(int n = 0; n <= entrees; n++) {
        prOUT >> plyrR[n];
    }
    prOUT.close();
    
    //cout << entrees << "\n";
    entrySort(plyrN, plyrR, entrees);
    
    
    if(entrees < 20 && entrees > 10) {
        prntLeader(plyrN, plyrR, entrees);
        
    } else prntLeader(plyrN, plyrR);
    
}

// sorted from lowest to highest round numbers using selection sort
void entrySort(string plyrN[], int plyrR[], int SIZE) {
    int temp1;    // a placeholder value for the arrays to swap
    string temp2; 
    //cout << SIZE << endl;;
    
    for(int n = 0; n < SIZE-1; n++) {
        //cout << n << endl;
        int minindx = n,
            min = plyrR[n];
        for(int x = n+1; x < SIZE; x++) {
            if(plyrR[x] < min) { 
                min = plyrR[x];
                minindx = x;
            }
        }
        //cout << "Working 2\n";
        //swaps array values
        temp1 = plyrR[minindx];
        plyrR[minindx] = plyrR[n];
        plyrR[n] = temp1;
        
        //swaps array values
        temp2 = plyrN[minindx];
        plyrN[minindx] = plyrN[n];
        plyrN[n] = temp2;
    }
}


// INCLUDE A DEFAULT ARGUEMENT FOR THE LEADERBOARD SIZE (10 entrees)
void prntLeader(string plyrN[], int plyrR[], int entrees) {
    cout << "      L E A D E R  B O A R D\n" 
         << " ================================\n";
    for(int n = 0; n < entrees; n++) {
        cout << setw(13) << plyrN[n] << "   ||   "; 
        cout << setw(7) << ((plyrR[n] != 0) ? plyrR[n]: 000) << endl;
    }
}



/*
 * Pseudo Code:
 * create output file stream
 * create input file stream
 * 
 * if: the file has no data, write "0 0", close file
 * 
 * open file for output: store file contents into variables:
 * variable 1 = number of games won
 * variable 2 = total games played
 * 
 * if: the player has won the current game, add 1 to variable 1
 * add 1 to variable 2 regardless of whether the player won
 * 
 * output the total win rate of the player
 * 
 * open file for storage
 * store contents of variable 1
 * input a space " "
 * store contents of variable 2
 */
// used at the end of the game
void getWR(unsigned wincnt, unsigned gamenum, bool playerW) {
    // VARIABLES:
    float winrate; // a value to be calculated at the end, or in the records menu, where the program will tell the user their win rate across
                   // all the games they've played
    
    
    // WIN RATE CALCULATION HERE
    // opens input and output objects
    ofstream winsIN;
    ifstream winsOUT("Winrecord.txt");

    // if program does not detect data in the file (ie: if the file has just been created)
    if(!(winsOUT >> wincnt >> gamenum)) {
        winsOUT.close(); // closes input stream
        winsIN.open("Winrecord.txt"); // opens file in output stream
        winsIN << wincnt << " " << gamenum; // outputs the game number and win count into the file (both will be 0 at this time)
        winsIN.close();
    }

    // reads from file
    winsOUT.open("Winrecord.txt"); // stores the current game number and win count into the wincnt and gamenum variables
    winsOUT >> wincnt >> gamenum;
    winsOUT.close();
    //cout << wincnt << " " << gamenum << endl;

    if(playerW) wincnt++; // if the player won, increases win count

    gamenum++; // increases game count regardless of if the player won or not

    //cout << wincnt << " " << gamenum;
    winrate = (static_cast<float>(wincnt)/gamenum)*100; // uses static cast to force floating point division
    cout << fixed << setprecision(2) << "\nYour Win Rate is " << winrate << "%\n";

    // writes new values back to file
    winsIN.open("Winrecord.txt");
    winsIN << wincnt << " " << gamenum; // separated by space so that the program knows to distinguish the 
    winsIN.close();                     // two numbers as different variables 
}

/*
 * Pseudo Code:
 * create output file stream
 * create input file stream
 * 
 * if: the file has no data, write "0 0", close file, return 1 (will prompt the user to play games to fill the records.)
 * 
 * 
 * open file for output: store file contents into variables:
 * variable 1 = number of games won
 * variable 2 = total games played
 * 
 * output the total win rate of the player
 */
// used in the records section of the menu
int getWR() {
    unsigned int wincnt = 0,
                 gamenum = 0;
    // VARIABLES:
    float winrate; // a value to be calculated at the end, or in the records menu, where the program will tell the user their win rate across
                   // all the games they've played
    
    
    // WIN RATE CALCULATION HERE
    // opens input and output objects
    ofstream winsIN;
    ifstream winsOUT("Winrecord.txt");

    // if program does not detect data in the file (ie: if the file has just been created)
    if(!(winsOUT >> wincnt >> gamenum)) {
        winsOUT.close(); // closes input stream
        
        winsIN.open("Winrecord.txt"); // opens file in output stream
        winsIN << wincnt << " " << gamenum; // outputs the game number and win count into the file (both will be 0 at this time)
        winsIN.close();
        
        cout << "Play A Game In Order to Display Records.\n";
        return 0;
    } 

    if(wincnt == 0 && gamenum == 0) {
        cout << "Play A Game In Order to Display Records.\n";
        return 0;
    }
    
    // reads from file
    winsOUT.open("Winrecord.txt"); // stores the current game number and win count into the wincnt and gamenum variables
    winsOUT >> wincnt >> gamenum;
    winsOUT.close();
    //cout << wincnt << " " << gamenum << endl;


    //cout << wincnt << " " << gamenum;
    winrate = (static_cast<float>(wincnt)/gamenum)*100; // uses static cast to force floating point division
    cout << fixed << setprecision(2) << "\nYour Win Rate is " << winrate << "%\n";
    //cout << "working";
    return 0;
}

/*
 * open round record file for reading
 * set the vector to zero etnrees
 * 
 * while: a round number is read from the file into a temp variable {
 *    push back the vector and store the temp variable into the new slot in the vector
 * }
 * close the file
 * 
 * push back the vector and store round count from the most recent game played
 * 
 * open the round record file for writing
 * for: count is less than the size of the vector {
 *    store the value of the vector at index count followed by a " "
 * }
 */
void storeRoundNum(vector<unsigned int> rounds, unsigned int roundno) {
    ifstream rndsOUT("RoundRecord.txt");
    ofstream rndsIN;
    unsigned int roundct;
    
    rounds.clear();
    
    while(rndsOUT >> roundct) {
        rounds.push_back(roundct);
    }
    rndsOUT.close();
    rounds.push_back(roundno);
    
    rndsIN.open("RoundRecord.txt");
    for(int n = 0; n < rounds.size(); n++) {
        rndsIN << rounds[n] << " ";
    }
}

/*
 * Pseudo Code:
 * create output file stream
 * create input file stream
 * 
 * if: the file has no data, close file, return
 * clear the vector
 * 
 * open files for reading: winrecord and roundrecord
 * read first value into a dummy variable, and the second value into game number variable
 * close the winrecord file
 * 
 * while: a value is read from the roundrecord file {
 *    push back the vector and store the next value
 * }
 * close the roundrecords file
 * 
 * for: count is less than the size of the vecto, incr index {
 *    add the current index of the vector to a total sum of rounds
 * }
 * 
 * average = total sum divided by the game number
 * 
 * output the total average rounds of the player
 */
int getRoundAVE(vector<unsigned int> rounds) {
    unsigned int rndcnt = 0,
                 dummy,
                 gamenum;
    float rndave;
    unsigned int temp = 0;
    //cout << "working";
    ifstream winsOUT("Winrecord.txt");
    ifstream rndsOUT("Roundrecord.txt");
    if(!(winsOUT >> dummy >> gamenum)) {
        winsOUT.close();
        return 0;
        
    } else if(!(rndsOUT >> dummy)) {
        rndsOUT.close();
        return 0;
    }
    rndsOUT.close();
    
    winsOUT.open("Winrecord.txt");
    winsOUT >> dummy >> gamenum;
    winsOUT.close();
    
    rounds.clear();
    
    rndsOUT.open("Roundrecord.txt");
    while(rndsOUT >> temp) {
        rounds.push_back(temp);
    }
    rndsOUT.close();

    for(int n = 0; n < rounds.size(); n++) {
        rndcnt += rounds[n];
        
    }

    rndave = static_cast<float>(rndcnt)/gamenum;
    
    cout << "Your games last on average " << fixed << setprecision(2) << rndave << " rounds\n";
    return rndave;
}

/*
 * Pseudo Code:
 * create output file stream
 * create input file stream
 * 
 * if: the file has no data, close file, return
 * clear the vector
 * 
 * open files for reading: winrecord and roundrecord
 * read first value into a dummy variable, and the second value into game number variable, and 
 * read the roundrecord into a vector
 * 
 * if: a value was not read from either of the two files, close both files and return
 * 
 * close the roundrecord file
 * close the winrecord file
 * 
 * clear the vector
 * 
 * while: a value is read from the roundrecord file {
 *    push back the vector and store the next value
 * }
 * close the roundrecords file
 * 
 * for: count is less than the size of the vecto, incr index {
 *    add the square of the current vector value at the current index subtracted by the round average to a sum
 * }
 * 
 * std deviation = sqrt of the total sum divided by the size of the vector
 * 
 * output the standard deviation, return
 */
void getSTDdeviation(vector<unsigned int> rounds, float rndave) {
    unsigned int rndsum = 0,
                 dummy,
                 gamenum,
                 temp = 0;
    float stdD;    
    
    ifstream winsOUT("Winrecord.txt");
    ifstream rndsOUT("Roundrecord.txt");
    if(!(winsOUT >> dummy >> gamenum)) {
        winsOUT.close();
        return;
        
    } else if(!(rndsOUT >> dummy)) {
        rndsOUT.close();
        return;
    }
    rndsOUT.close();
    winsOUT.close();
    
    // clears the vector to prepare for initialization
    rounds.clear();
    
    rndsOUT.open("Roundrecord.txt");
    while(rndsOUT >> temp) {
        //cout << temp << endl;
        rounds.push_back(temp);
    }
    rndsOUT.close();
    //cout << rounds.size();
    for(int n = 0; n < rounds.size(); n++) {
        //cout << "dfrgsdfg " << rounds[n];
        rndsum += pow(rounds[n]-rndave, 2);
        //cout << rndsum << endl;
    }
     
    // calculate standard deviation
    stdD = sqrt(rndsum/(rounds.size()));
    
    cout << "Your round average has a standard deviation of " << fixed << setprecision(2) << stdD << "\n";
    return;
}

/*
 * Pseudo Code:
 * prompt the user to input whether they would like to clear the file records or not
 * input: user choice
 * 
 * if: user choice is yes {
 *    open winrecord file for writing
 *    write to file ""
 *    close file
 *    open roundrecord file for writing
 *    write to file ""
 *    close file
 *    open playernames file for writing
 *    write to file ""
 *    close file
 *    open playerrounds file for writing
 *    write to file ""
 *    close file
 * }
 *    output whether the records were cleared or not
 */
void recordWipe() {
    ofstream winsIN;
    ofstream rndsIN;
    ofstream pnIN;
    ofstream prIN;
    char clear;  // a variable to hold y/n, used to determine whether the player wishes to clear the win record
    
    cout << " Would you like to clear the records? (Y/N)\n";
    cin >> clear;
    if(clear == 'Y' || clear == 'y') {
        winsIN.open("Winrecord.txt");
        winsIN << ""; // rewrites the file as nothing ("")
        winsIN.close();
        rndsIN.open("Roundrecord.txt");
        rndsIN << "";
        rndsIN.close();
        pnIN.open("Playernames.txt");
        pnIN << "";
        pnIN.close();
        prIN.open("PlayerRounds.txt");
        prIN << "";
        prIN.close();
        
        cout << "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n"
             << " THE RECORDS HAVE BEEN CLEARED\n\n";
    } else cout << "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n"
                << " THE RECORDS HAVE NOT BEEN CLEARED\n\n";
}