/* 
 * File:   main.cpp
 * Author: Landon Renaud
 * Created on June 24, 5:02 PM
 * Purpose: Calculate and display tax and tip owed on a restaurant bill
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Mathematical/Physics/Conversions, Higher dimensioned arrays

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed

    //Declare Variables
    float bill, // The price listed on the restaurant bill
          tax,  // The sales tax owed based on the price listed on the bill
          tip;  // The tip, calculated from the combined cost of the bill and the sales tax
    
    //Initialize Variables
    bill = 88.67;
    
    //Map inputs to outputs -> The Process
    tax = bill*0.0675;      // The sales tax rate is 6.75%
    tip = (tax + bill)*0.2; // The tip is rated at 20%
    
    //Display Results
    cout << "Price: $" << bill << endl << "Sales Tax: $" << tax << endl << "Tip (20%): $" << tip << endl;
            
    //Exit stage right
    return 0;
}

