/* 
 * File:   main.cpp
 * Author: Landon Renaud
 * Created on June 22, 2022, 8:12 PM
 * Purpose: Calculate the total amount of dollars payed for a stock purchase and the commission payed on them
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Mathematical/Physics/Conversions, Higher dimensioned arrays


//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    
    //Declare Variables
    float ttlcmssn, // The amount in dollars payed as commission
          ttl,      // The total amount of dollars paid
          shrs,     // The amount of stock shares purchased
          prce,     // The cost of purchasing all stock shares
          cmssn;    // The commission rate
    int stckprce;   // The price of 1 stock share
    
    //Initialize Variables
    shrs = 750;
    cmssn = 0.02;     // The commission is 2%, adjusted to 0.02 for the purposes of calculation
    stckprce = 35.00;

    //Map inputs to outputs -> The Process
    prce = (shrs*stckprce);
    ttlcmssn = prce * 0.02;
    ttl = prce + cmssn;

    //Display Results
    cout << "Kathryn Payed a total of $" << prce << " for 750 shares at $35.00 per share";
    cout << "\nThe amount of commission payed is $" << ttlcmssn << " At 2% per share";
    cout << "\nThe total amount payed in dollars is $" << ttl; 

    //Exit stage right
    return 0;
}

