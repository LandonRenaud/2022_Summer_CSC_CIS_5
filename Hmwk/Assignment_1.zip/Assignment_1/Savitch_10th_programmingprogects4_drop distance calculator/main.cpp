/* 
 * File:   main.cpp
 * Author: Landon Renaud
 * Created on June 26, 2022, 11:31 AM
 * Purpose: Calculate the distance an object has fallen based on the user input fall time
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Mathematical/Physics/Conversions, Higher dimensioned arrays


//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    
    //Declare Variables
    float dstnce, // The distance in feet an object has fallen based on the user defined fall time 
          time;   // float is used to allow the user to input decimals

    //Initialize Variables
    cout << "How long has the object been falling? (please only input a numerical value) ";
    cin >> time;

    //Map inputs to outputs -> The Process
    dstnce = (32*(time*time))/2;  // The acceleration is given as 32 feet per second

    //Display Results
    cout << "The object has fallen " << dstnce << " feet in " << time << " seconds\n";

    //Exit stage right
    return 0;
}

