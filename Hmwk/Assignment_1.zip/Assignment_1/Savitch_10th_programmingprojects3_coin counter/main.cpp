/* 
 * File:   main.cpp
 * Author: Landon Renaud
 * Created on June 27, 2022, 1:52 PM
 * Purpose: Count a user's quarters, nickels, and dimes, and calculate their value
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Mathematical/Physics/Conversions, Higher dimensioned arrays

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    
    //Declare Variables
    unsigned int qrtrs, // qrtrs is the number of quarters
                 nckls, // nckls is the number of nickels
                 dms,   // dms is the number of dimes
                 ttl;   // ttl is the total amount of money in cents
    
    //Initialize Variables
    cout << "Please Enter Your Number of Quarters: ";
    cin >> qrtrs;
    cout << "\nPlease Enter Your Number of Dimes ";
    cin >> dms;
    cout << "\nPlease Enter Your Number of Nickels ";
    cin >> nckls;

    //Map inputs to outputs -> The Process
    ttl = qrtrs*25 + nckls*5 + dms*10;

    //Display Results
    cout << "\nYou have a total of " << ttl << " cents";

    //Exit stage right
    return 0;
}


