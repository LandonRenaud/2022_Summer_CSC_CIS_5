/* 
 * File:   main.cpp
 * Author: Landon Renaud
 * Created on June 22, 2022, 7:56 PM
 * Purpose: Calculate the distance a car can travel in a town or on a highway with 20 gallons of gas
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Mathematical/Physics/Conversions, Higher dimensioned arrays


//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    
    //Declare Variables
    float mpgtwn,  // The miles per gallon the car performs at in the town, units are m/g or miles per gallon
          mpghw;   // The miles per gallon the car performs at on the highway, units are m/g or miles per gallon
    int tank,      // The capacity of the car's tank, units are gallons
        dstncetwn, // The distance the car can travel in the town, units are miles
        dstncehw;  // The distance the car can travel on the , units are miles

    //Initialize Variables
    tank = 20;
    mpgtwn = 23.5;
    mpghw = 28.9;

    //Map inputs to outputs -> The Process
    dstncetwn = mpgtwn*tank;
    dstncehw = mpghw*tank;

    //Display Results
    cout << "The total distance the car can travel with 1 tank of gas is:\nHighway: " << dstncehw << " miles\nTown: " << dstncetwn << " miles\n";

    //Exit stage right
    return 0;
}


