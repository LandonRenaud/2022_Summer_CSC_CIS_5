/* 
 * File:   main.cpp
 * Author: Landon Renaud
 * Created on June 26, 2022, 12:06 PM
 * Purpose: Add and Multiply two user input integers
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Mathematical/Physics/Conversions, Higher dimensioned arrays

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    
    //Declare Variables
    unsigned int int1,  // The first user input integer
                 int2,  // The second user input integer
                 sum,   // The sum of the two integers
                 prdct; // The product of the two integers

    //Initialize Variables
    cout << "Please input two INTEGERS\nInteger 1: ";
    cin >> int1;
    cout << "Integer 2: ";
    cin >> int2;

    //Map inputs to outputs -> The Process
    sum = int1 + int2;
    prdct = int1*int2;

    //Display Results
    cout << "\nThe sum of your two integers is " << sum << "\nThe product of your two integers is " << prdct;

    //Exit stage right
    return 0;
}
