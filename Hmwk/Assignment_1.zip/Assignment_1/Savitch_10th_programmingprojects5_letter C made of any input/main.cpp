/* 
 * File:   main.cpp
 * Author: Landon Renaud
 * Created on June 27, 2022, 2:22 PM
 * Purpose: Read a user's input and create a "c" shape using the user's input
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Mathematical/Physics/Conversions, Higher dimensioned arrays

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed

    //Declare Variables
    char inpt; // The user input character which will be used to make a "c" shape.
    
    //Initialize Variables
    cout << "Please input ONE character (Only the first character will be read): ";
    cin >> inpt;
    
    //Map inputs to outputs -> The Process

    //Display Results
    cout << "  " << inpt << inpt << inpt << endl;
    cout << " " << inpt << "   " << inpt << endl;
    cout << inpt << endl;
    cout << inpt << endl;
    cout << " " << inpt << "   " << inpt << endl;
    cout << "  " << inpt << inpt << inpt << endl;
    
    
    //Exit stage right
    return 0;
}

