/* 
 * File:   main.cpp
 * Author: Landon Renaud
 * Created on July, 2022, 12:42 AM
 * Purpose: Menu for all problems in homework assignment 5
 */

//System Libraries
#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants
//Mathematical/Physics/Conversions, Higher dimensioned arrays
void prob1();
void minmax(int, int, int, int& ,int&);

void prob2();
int fctrl(int);

void prob3();
bool isPrime(int);

void prob4();
int collatz(int);

void prob5();
int collatz2(int);

void prob6();
void findtime(unsigned short, unsigned short, char);
void findwait(unsigned short, unsigned, unsigned short, char);

void prob7();
void timeconv(unsigned short&, unsigned short&, string&);

void prob8();
float psntVal(float, float, int);

void prob9();
void getScre(int& ,int& ,int& , int&, int&);
float calcAvg(int,int,int,int,int);


//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    
    //Declare Variables
    char again;
    unsigned short prob;
    //Initialize Variables
    do {
        cout << "Menu Program For Homework Assignment 5 Problems\nPlease input a number (1-9): ";
        cin >> prob;
    //Map inputs to outputs -> The Process
        switch(prob) {
            case 1: {
                prob1();
                break;
            }
            case 2: {
                prob2();
                break;
            }
            case 3: {
                prob3();
                break;
            }
            case 4: {
                prob4();
                break;
            }
            case 5: {
                prob5();
                break;
            }
            case 6: {
                prob6();
                break;
            }
            case 7: {
                prob7();
                break;
            }
            case 8: {
                prob8();
                break;
            }
            case 9: {
                prob9();
                break;
            }
            default: cout << "Error: Invalid input";
        }
        
        cout << "\n\nWould you like to run another program? (Y/N):\n";
        cin >> again;
    } while(again == 'Y' || again == 'y');
    
    //Exit stage right
    return 0;
}



void prob1() {
    //Declare Variables
    int n1, n2, n3, max, min;
    //Initialize Variables
    cout << "Input 3 numbers\n";
    cin >> n1 >> n2 >> n3; // gets the three numbers
    max = 0;
    min = 0;
    //Process/Map inputs to outputs
    minmax(n1, n2, n3, max, min);
    //Output data
    cout << "Min = " << min << endl;
    cout << "Max = " << max;
}

void minmax(int n1, int n2, int n3, int& max, int& min) {
    if(n1 > n2 && n1 > n3) { // if the first number is max
        max = n1;
        if(n2 > n3) {
            min = n3; // if the third number is min
        } else {
            min = n2; // if the second number is min
        }
    } else if(n2 > n1 && n2 > n3) { // if the second num if max
        max = n2;
        if(n1 > n3) { 
            min = n3; // if the third number is min
        } else {
            min = n1; // if the first number is min
        }
    } else /*if(n3 > n1 && n3 > n2)*/ { // if the third number is max
        max = n3;
        if(n1 > n2) {
            min = n2; // if the second number is min
        } else {
            min = n1; // if the first number is min
        }
    }
}



void prob2() {
    //Declare Variables
    int limit;
    long int fac;
    //Initialize Variables
    cout << "This program calculates the factorial using a function prototype found in the template for this problem.\n";
    cout << "Input the number for the function.\n";
    cin >> limit;
    //Process/Map inputs to outputs
    fac = fctrl(limit);
    //Output data
    cout << limit << "! = " << fac;
}

int fctrl(int limit) {
    long int fac = 1;
    for(int n = 1; n <= limit; n++) {
        fac *= n;
    }
    return fac;
}



void prob3() {
    //Declare Variables
    int num;
    //Initialize Variables
    cout << "Input a number to test if Prime.\n";
    cin >> num;
    
    //Process/Map inputs to outputs
    
    //Output data
    if(isPrime(num)) {
        cout << num << " is prime.";
    } else {
        cout << num << " is not prime.";
    }
}

bool isPrime(int num) {
    int n = 2;
    bool prime = false;
    
    while ((num%n) != 0 && n < (num/2)) {
        prime = false;
        n++;
    }
    if((num%n) == 1) {
        prime = true;
    }
    return prime;
}



void prob4() {
    //Declare Variables
    int n;
    
    //Initialize Variables
    cout << "Collatz Conjecture Test\n";
    cout << "Input a sequence start\n";
    cin >> n;
    
    //Process/Map inputs to outputs
    cout << "Sequence start of " << n <<" cycles to 1 in " <<
            collatz(n) << " steps";
}

int collatz(int n) {
    int term;
    int count = 1;
    term = n;
    while(term != 1) {
        if(term%2 == 1) {
            term = 3*term+1;
        } else {
            term /= 2;
        }
        count++;
    }
    return count;
}



void prob5() {
    //Declare Variables
    int n;
    
    //Initialize Variables
    cout << "Collatz Conjecture Test\n";
    cout << "Input a sequence start\n";
    cin >> n;
    
    //Process/Map inputs to outputs
    
    
    //Output data
    collatz2(n);
}

int collatz2(int n) {
    int term;
    int count = 1;
    term = n;
    cout << n << ", ";
    while(term != 1) {
        if(term%2 == 1) {
            term = 3*term+1;
        } else {
            term /= 2;
        }
        if(term != 1) cout << term << ", ";
        count++;
    }
    cout << term;
    cout << "\nSequence start of " << n <<" cycles to 1 in " <<
            count << " steps";
    return count;
}



void prob6() {
    //Declare Variables
    char again,  // variable to decide if the user wants to repeat the program
         ampm;   // a char to determine if the time is AM or PM
    unsigned short hours,    // the current hours
                   minutes; // the current minutes
    unsigned wait = 0;    // the wait time in minutes
    
    //Initialize or input i.e. set variable values
    do {
        cout << "Enter hour:\n\n";
        cin >> hours;
        cout << "Enter minutes:\n\n";
        cin >> minutes;
        cout << "Enter A for AM, P for PM:\n\n";
        cin >> ampm;
        cout << "Enter waiting time:\n\n";
        cin >> wait;
        
        
    //Map inputs -> outputs, Display the outputs
        if(ampm == 'a') ampm = 'A'; // input validation
        if(ampm == 'p') ampm = 'P';
    
    
        findtime(hours, minutes, ampm); // calls time finder
        findwait(hours, wait, minutes, ampm); // calls new time finder
        
        cout << "Would you like to enter another time? (Y/N)\n";
        cin >> again;
        if(again == 'y') cout << endl; // ends line if the program runs again for formatting purposes
    } while (again == 'y'); // ends if ampm == 'n'
}

void findtime(unsigned short hours, unsigned short minutes, char ampm) {
    
    cout << "Current time = ";
    if(hours < 10) cout << "0" << hours << ":"; // if the hours are less than 10, prints a space
    else cout << hours << ":";
    if(minutes < 10) cout << "0" << minutes; // if the minutes are less than 10, prints a space
    else cout << minutes;
    
    if(ampm == 'A') cout << " AM\n";
    if(ampm == 'P') cout << " PM\n";
}
void findwait(unsigned short hours, unsigned wait, unsigned short minutes, char ampm) {
    int nhours = hours + (wait/60); // sets the new hours 
    //cout << nhours;
    int nmins = minutes + (wait-(60*(wait/60))); // sets the new minutes
    //cout << nmins;
    while(nmins >= 60) { // if the minutes are over 60, resets them, adds to hours
        nmins -= 60;
        nhours += 1;
    }
    while(nhours >= 13) { // if the hours are over 12, resets them, changes am to pm or pm to am
        if(nhours >= 13) nhours -= 12;
        if(nhours == 0) nhours += 1;
        if(ampm == 'A') ampm = 'P';
        else ampm = 'A';
    }
    // outputting the t
    cout << "Time after waiting period = ";
    if(nhours < 10) cout << "0" << nhours << ":"; // if the hours are less than 10, prints a space
    else cout << nhours << ":";
    
    if(nmins < 10) cout << "0" << nmins; // if the minutes are less than 10, prints a space
    else cout << nmins;
    
    if(ampm == 'A') cout << " AM\n\n";
    if(ampm == 'P') cout << " PM\n\n";
}



void prob7() {
    //Declare Variables
    unsigned short hour, 
             minute;
    char colon,
         again;
    string ampm;

    //Initialize Variables
    cout << "Military Time Converter to Standard Time\n"
         << "Input Military Time hh:mm\n";
    do {
        
        cin >> hour >> colon >> minute; // separates the values, takes out the colon
    
        //Map inputs to outputs -> The Process
        if(hour < 10) {
            cout << "0" << hour << colon << minute;
        } else cout << hour << colon << minute;
        
        if(hour > 24 || minute > 59) {
            cout << " is not a valid time\n";
        } else {
            timeconv(hour, minute, ampm);
    
            //Display Results
            cout << " = " << hour << colon << minute << ampm;
    
            
        }
        
        cout << "Would you like to convert another time? (y/n)\n";
        cin >> again;
    } while(again == 'y' || again == 'Y');
}

void timeconv(unsigned short& hour, unsigned short& minute, string& ampm) {
    if(hour >= 12) {
        if(hour > 12) hour -= 12;
        ampm = " PM\n";
    } else if(hour == 0) {
        hour += 12;
        ampm = " AM\n";
    } else {
        ampm = " AM\n";
    }
}



void prob8() {
    //Declare Variables
    float intrst,
          fval;
    int years;

    //Initialize Variables
    cout << "This is a Present Value Computation\nInput the Future Value in Dollars\n";
    cin >> fval;
    cout << "Input the Number of Years\n";
    cin >> years;
    cout << "Input the Interest Rate %/yr\n";
    cin >> intrst;

    //Map inputs to outputs -> The Process
    intrst /= 100;
    psntVal(fval, intrst, years);

    //Display Results
    cout << "The Present Value = $" << fixed << setprecision(2) << psntVal(fval, intrst, years);
}

float psntVal(float fval, float intrst, int years) {
    float prsntvl = (fval/(pow(1+intrst, years)));
    return prsntvl;
}



void prob9() {
    //Declare Variables
    int n1, // The scores of each test, 1-5
        n2,  
        n3,  
        n4,  
        n5;  
    
    //Initialize Variables
    cout << "Find the Average of Test Scores\nby removing the lowest value.\n";
    getScre(n1, n2, n3, n4, n5);
    
    //Display Results
    cout << fixed << setprecision(1) << "The average test score = " << calcAvg(n1, n2, n3, n4, n5);
}
// gets the scores
void getScre(int& n1,int& n2,int& n3, int& n4, int& n5) { // ampersand used to make sure the variable value is remembered
    cout << "Input the 5 test scores.\n";
    cin >> n1 >> n2 >> n3 >> n4 >> n5;
    if(1 > n1 || n1 > 100) cout << "error";
    if(1 > n2 || n3 > 100) cout << "error";
    if(1 > n3 || n3 > 100) cout << "error";
    if(1 > n4 || n4 > 100) cout << "error";
    if(1 > n5 || n5 > 100) cout << "error";
    
}

// calculates the average
float calcAvg(int n1,int n2,int n3,int n4,int n5) {
    if(n5 > n1 && n4 > n1 && n3 > n1 && n2 > n1) n1 = 0;
    else if(n5 > n2 && n4 > n2 && n3 > n2 && n1 > n2) n2 = 0;
    else if(n5 > n3 && n4 > n3 && n2 > n3 && n1 > n3) n3 = 0;
    else if(n5 > n4 && n3 > n4 && n2 > n4 && n1 > n4) n4 = 0;
    else n5 = 0;
    
    float ave;
    ave = (n1 + n2 + n3 + n4 + n5)/4;
    return ave;
}