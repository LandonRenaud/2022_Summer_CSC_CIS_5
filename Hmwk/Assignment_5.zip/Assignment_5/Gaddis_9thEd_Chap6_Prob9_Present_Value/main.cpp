/* 
 * File:   main.cpp
 * Author: Landon Renaud
 * Created on July 20, 2022, 3:03 PM
 * Purpose: calculate the present value using the present value function
 */

//System Libraries
#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants
//Mathematical/Physics/Conversions, Higher dimensioned arrays

//Function Prototypes
float psntVal(float, float, int);

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    
    //Declare Variables
    float intrst,
          fval;
    int years;

    //Initialize Variables
    cout << "This is a Present Value Computation\nInput the Future Value in Dollars\n";
    cin >> fval;
    cout << "Input the Number of Years\n";
    cin >> years;
    cout << "Input the Interest Rate %/yr\n";
    cin >> intrst;

    //Map inputs to outputs -> The Process
    intrst /= 100;
    psntVal(fval, intrst, years);

    //Display Results
    cout << "The Present Value = $" << fixed << setprecision(2) << psntVal(fval, intrst, years);

    //Exit stage right
    return 0;
}

float psntVal(float fval, float intrst, int years) {
    float prsntvl = (fval/(pow(1+intrst, years)));
    return prsntvl;
}