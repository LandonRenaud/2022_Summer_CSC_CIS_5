/* 
 * Author: Landon Renaud
 * Created on July 20, 2022, 1:24 PM
 * Purpose: Output the length of a collatz sequence as well as its terms
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes
int collatz(int);//3n+1 sequence

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    int n;
    
    //Initialize Variables
    cout << "Collatz Conjecture Test\n";
    cout << "Input a sequence start\n";
    cin >> n;
    
    //Process/Map inputs to outputs
    
    
    //Output data
    collatz(n);
    //Exit stage right!
    return 0;
}

int collatz(int n) {
    int term;
    int count = 1;
    term = n;
    cout << n << ", ";
    while(term != 1) {
        if(term%2 == 1) {
            term = 3*term+1;
        } else {
            term /= 2;
        }
        if(term != 1) cout << term << ", ";
        count++;
    }
    cout << term;
    cout << "\nSequence start of " << n <<" cycles to 1 in " <<
            count << " steps";
    return count;
}
