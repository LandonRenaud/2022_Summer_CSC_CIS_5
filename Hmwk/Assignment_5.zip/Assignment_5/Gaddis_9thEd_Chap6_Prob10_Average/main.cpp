/* 
 * File:   main.cpp
 * Author: Landon Renaud
 * Created on July 20, 2022, 2:52 PM
 * Purpose: calculate the average of 5 test scores after dropping the lowest score
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants
//Mathematical/Physics/Conversions, Higher dimensioned arrays

//Function Prototypes
void getScre(int& ,int& ,int& , int&, int&);
float calcAvg(int,int,int,int,int);

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    
    //Declare Variables
    int n1, // The scores of each test, 1-5
        n2,  
        n3,  
        n4,  
        n5;  
    
    //Initialize Variables
    cout << "Find the Average of Test Scores\nby removing the lowest value.\n";
    getScre(n1, n2, n3, n4, n5);
    
    //Map inputs to outputs -> The Process
    
    
    //Display Results
    cout << fixed << setprecision(1) << "The average test score = " << calcAvg(n1, n2, n3, n4, n5);
    
    //Exit stage right
    return 0;
}

// gets the scores
void getScre(int& n1,int& n2,int& n3, int& n4, int& n5) { // ampersand used to make sure the variable value is remembered
    cout << "Input the 5 test scores.\n";
    cin >> n1 >> n2 >> n3 >> n4 >> n5;
    if(1 > n1 || n1 > 100) cout << "error";
    if(1 > n2 || n3 > 100) cout << "error";
    if(1 > n3 || n3 > 100) cout << "error";
    if(1 > n4 || n4 > 100) cout << "error";
    if(1 > n5 || n5 > 100) cout << "error";
    
}

// calculates the average
float calcAvg(int n1,int n2,int n3,int n4,int n5) {
    if(n5 > n1 && n4 > n1 && n3 > n1 && n2 > n1) n1 = 0;
    else if(n5 > n2 && n4 > n2 && n3 > n2 && n1 > n2) n2 = 0;
    else if(n5 > n3 && n4 > n3 && n2 > n3 && n1 > n3) n3 = 0;
    else if(n5 > n4 && n3 > n4 && n2 > n4 && n1 > n4) n4 = 0;
    else n5 = 0;
    
    float ave;
    ave = (n1 + n2 + n3 + n4 + n5)/4;
    return ave;
}