/* 
 * Author: Landon Renaud
 * Created on July 20, 2022, 12:51 PM
 * Purpose:  find a factorial up to a user defined limit
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes
int fctrl(int);//Function to write for this problem

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    int limit;
    long int fac;
    //Initialize Variables
    cout << "This program calculates the factorial using a function prototype found in the template for this problem.\n";
    cout << "Input the number for the function.\n";
    cin >> limit;
    //Process/Map inputs to outputs
    fac = fctrl(limit);
    //Output data
    cout << limit << "! = " << fac;
    //Exit stage right!
    return 0;
}

int fctrl(int limit) {
    long int fac = 1;
    for(int n = 1; n <= limit; n++) {
        fac *= n;
    }
    return fac;
}