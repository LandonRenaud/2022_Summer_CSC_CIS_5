/* 
 * Author: Landon Renaud
 * Created on July 19, 2022, 11:20 PM
 * Purpose:  find the minimum and maximum of 3 numbers
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes
void minmax(int, int, int, int& ,int&); // Function to find the min and max

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    int n1, n2, n3, max, min;
    //Initialize Variables
    cout << "Input 3 numbers\n";
    cin >> n1 >> n2 >> n3; // gets the three numbers
    max = 0;
    min = 0;
    //Process/Map inputs to outputs
    minmax(n1, n2, n3, max, min);
    //Output data
    cout << "Min = " << min << endl;
    cout << "Max = " << max;
    //Exit stage right!
    return 0;
}


void minmax(int n1, int n2, int n3, int& max, int& min) {
    if(n1 > n2 && n1 > n3) { // if the first number is max
        max = n1;
        if(n2 > n3) {
            min = n3; // if the third number is min
        } else {
            min = n2; // if the second number is min
        }
    } else if(n2 > n1 && n2 > n3) { // if the second num if max
        max = n2;
        if(n1 > n3) { 
            min = n3; // if the third number is min
        } else {
            min = n1; // if the first number is min
        }
    } else /*if(n3 > n1 && n3 > n2)*/ { // if the third number is max
        max = n3;
        if(n1 > n2) {
            min = n2; // if the second number is min
        } else {
            min = n1; // if the first number is min
        }
    }
}