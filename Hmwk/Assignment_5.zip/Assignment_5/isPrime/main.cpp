/* 
 * Author: Landon Renaud
 * Created on July 20, 2022, 1:14 PM
 * Purpose:  Find if a number is prime
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes
bool isPrime(int);//Determine if the input number is prime.

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    int num;
    //Initialize Variables
    cout << "Input a number to test if Prime.\n";
    cin >> num;
    
    //Process/Map inputs to outputs
    
    //Output data
    if(isPrime(num)) {
        cout << num << " is prime.";
    } else {
        cout << num << " is not prime.";
    }
    //Exit stage right!
    return 0;
}

bool isPrime(int num) {
    int n = 2;
    bool prime = false;
    
    while ((num%n) != 0 && n < (num/2)) {
        prime = false;
        n++;
    }
    if((num%n) == 1) {
        prime = true;
    }
    return prime;
}
