/* 
 * File:  main.cpp 
 * Author: Landon Renaud
 * Created on July 20, 2022, 1:30 PM
 * Purpose:  Set a timer
 */

//System Libraries
#include <iostream>  //Input/Output Library
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes
void findtime(unsigned short, unsigned short, char); // finds the current time
void findwait(unsigned short, unsigned, unsigned short, char); // finds the time after wait

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    char again,  // variable to decide if the user wants to repeat the program
         ampm;   // a char to determine if the time is AM or PM
    unsigned short hours,    // the current hours
                   minutes; // the current minutes
    unsigned wait = 0;    // the wait time in minutes
    
    //Initialize or input i.e. set variable values
    do {
        cout << "Enter hour:\n\n";
        cin >> hours;
        cout << "Enter minutes:\n\n";
        cin >> minutes;
        cout << "Enter A for AM, P for PM:\n\n";
        cin >> ampm;
        cout << "Enter waiting time:\n\n";
        cin >> wait;
        
        
    //Map inputs -> outputs, Display the outputs
        if(ampm == 'a') ampm = 'A'; // input validation
        if(ampm == 'p') ampm = 'P';
    
    
        findtime(hours, minutes, ampm); // calls time finder
        findwait(hours, wait, minutes, ampm); // calls new time finder
        
        cout << "Again:\n";
        cin >> again;
        if(again == 'y') cout << endl; // ends line if the program runs again for formatting purposes
    } while (again == 'y'); // ends if ampm == 'n'
    //Exit stage right or left!
    return 0;
}

// finds the current time
void findtime(unsigned short hours, unsigned short minutes, char ampm) {
    
    cout << "Current time = ";
    if(hours < 10) cout << "0" << hours << ":"; // if the hours are less than 10, prints a space
    else cout << hours << ":";
    if(minutes < 10) cout << "0" << minutes; // if the minutes are less than 10, prints a space
    else cout << minutes;
    
    if(ampm == 'A') cout << " AM\n";
    if(ampm == 'P') cout << " PM\n";
}

// finds the time after wait
void findwait(unsigned short hours, unsigned wait, unsigned short minutes, char ampm) {
    int nhours = hours + (wait/60); // sets the new hours 
    //cout << nhours;
    int nmins = minutes + (wait-(60*(wait/60))); // sets the new minutes
    //cout << nmins;
    while(nmins >= 60) { // if the minutes are over 60, resets them, adds to hours
        nmins -= 60;
        nhours += 1;
    }
    while(nhours >= 13) { // if the hours are over 12, resets them, changes am to pm or pm to am
        if(nhours >= 13) nhours -= 12;
        if(nhours == 0) nhours += 1;
        if(ampm == 'A') ampm = 'P';
        else ampm = 'A';
    }
    // outputting the t
    cout << "Time after waiting period = ";
    if(nhours < 10) cout << "0" << nhours << ":"; // if the hours are less than 10, prints a space
    else cout << nhours << ":";
    
    if(nmins < 10) cout << "0" << nmins; // if the minutes are less than 10, prints a space
    else cout << nmins;
    
    if(ampm == 'A') cout << " AM\n\n";
    if(ampm == 'P') cout << " PM\n\n";
}