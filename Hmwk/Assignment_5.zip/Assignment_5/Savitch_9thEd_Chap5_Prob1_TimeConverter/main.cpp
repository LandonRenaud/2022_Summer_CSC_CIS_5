/* 
 * File:   main.cpp
 * Author: Landon Renaud
 * Created on July 20, 2022, 2:43 PM
 * Purpose: convert Military time to Standard
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Mathematical/Physics/Conversions, Higher dimensioned arrays

//Function Prototypes
void timeconv(unsigned short&, unsigned short&, string&);

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    
    //Declare Variables
    unsigned short hour, 
             minute;
    char colon,
         again;
    string ampm;

    //Initialize Variables
    cout << "Military Time Converter to Standard Time\n"
         << "Input Military Time hh:mm\n";
    do {
        
        cin >> hour >> colon >> minute; // separates the values, takes out the colon
    
        //Map inputs to outputs -> The Process
        if(hour < 10) {
            cout << "0" << hour << colon << minute;
        } else cout << hour << colon << minute;
        
        if(hour > 24 || minute > 59) {
            cout << " is not a valid time\n";
        } else {
            timeconv(hour, minute, ampm);
    
            //Display Results
            cout << " = " << hour << colon << minute << ampm;
    
            
        }
        
        cout << "Would you like to convert another time (y/n)\n";
        cin >> again;
    } while(again == 'y' || again == 'Y');
    //Exit stage right
    return 0;
}

// function to convert time
void timeconv(unsigned short& hour, unsigned short& minute, string& ampm) {
    if(hour >= 12) {
        if(hour > 12) hour -= 12;
        ampm = " PM\n";
    } else if(hour == 0) {
        hour += 12;
        ampm = " AM\n";
    } else {
        ampm = " AM\n";
    }
}
