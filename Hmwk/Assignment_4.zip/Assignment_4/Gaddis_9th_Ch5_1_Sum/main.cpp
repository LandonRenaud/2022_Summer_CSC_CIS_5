/* 
 * File:   main.cpp
 * Author: Landon Renaud
 * Created on July 11, 2022, 6:35 PM
 * Purpose:  Find the sum of all numbers from 1 to a user defined limit
 */

//System Libraries
#include <iostream>  //Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    int limit,      // the user defined limit
        sum = 0;    // the sum of all numbers to the limit
    
    //Initialize or input i.e. set variable values
    cin >> limit; // gets limit from the user
    
    //Map inputs -> outputs
    for(int n = 1; n <= limit; ++n) { // uses n as the counter for the for loop
        sum += n;   // adds n, because n will always increase by 1 for every cycle
    }
    
    //Display the outputs
    cout << "Sum = " << sum;

    //Exit stage right or left!
    return 0;
}