/* 
 * File:   main.cpp
 * Author: Landon Renaud
 * Created on July 11, 2022, 6:40 PM
 * Purpose:  calculate the user's pay in pennies
 */

//System Libraries
#include <iostream>  //Input/Output Library
#include <iomanip>   //IO manipulation library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    int days,
        dailypay = 1;
    double total = 0; //the total pay earned
    // *** DOUBLE data type used. When using float data type, test case 3 returns with a red X  ***
    // ***                        Thus the double data type was used                            ***
    
    //Initialize or input i.e. set variable values
    cin >> days;
    
    //Map inputs -> outputs
    if(days < 1) {    // input validation: outputs an error if days worked is less than 1
        cout << "Number of days worked is less than one.";
        return 0;
    }
    
    for(int n = 0; n < days; ++n) {
        total += dailypay;   // adds the day's pay to the total paycheck
        dailypay *= 2;       // doubles pay for the nnust day
    }
    
    total = (total/100); //converts to cents
    
    //Display the outputs
    cout << fixed << setprecision(2) << "Pay = $" << total;

    //Exit stage right or left!
    return 0;
}
