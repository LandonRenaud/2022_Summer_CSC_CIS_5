/* 
 * File:   main.cpp
 * Author: Landon Renaud
 * Created on July 12, 2022, 1:54 PM
 * Purpose:  make a rectangle with user defined letter and side length
 */

//System Libraries
#include <iostream>  //Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    char var; // the user's character input
    int num;  // the sidelengh of the square/rectangle
    
    //Initialize or input i.e. set variable values
    cin >> num >> var;
    
    //Map inputs -> outputs


    
    //Display the outputs
    for(int n = 0; n < num; ++n) {      // loop determines the number of lines
        for(int a = 0; a < num; ++a) {  // loop determines number of characters per line
            cout << var;
        }
        
        if(n < num-1) {     // if statement used to avoid an endl at the end of the program
            cout << endl;
        }
    }
    //Exit stage right or left!
    return 0;
}