/* 
 * File:   main.cpp
 * Author: Landon Renaud
 * Created on July 12, 2022, 6:24 PM
 * Purpose:  calculate inflation rate and predict inflation
 */

//System Libraries
#include <iostream>  //Input/Output Library
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    char again;  // used for do-while statement
    float crrntpr,  // current price
          oldpr,    // old price
          irate,    // inflation rate
          pr1yr,    // inflated price in a year
          pr2yr;    // inflated price in 2 years
    
    //Initialize or input i.e. set variable values
    do {
    cout << "Enter current price:\n";
    cin >> crrntpr;
    cout << "Enter year-ago price:\n";
    cin >> oldpr;
    
    
    irate = (crrntpr-oldpr)/oldpr; // finds inflation rate
    pr1yr = crrntpr*(1+irate);  // finds price in 1 year
    pr2yr = pr1yr*(1+irate);    // finds price in 2 years
    irate *= 100;   // converts inflation rate to a percent value
    
    cout << fixed << setprecision(2);
    cout << "Inflation rate: " << irate << "%\n\n";
    cout << "Price in one year: $" << pr1yr << endl;
    cout << "Price in two year: $" << pr2yr << endl << endl;
    
    cout << "Again:\n"; // determines if the user wants to use the program again
    cin >> again;
    
    if(again == 'y') cout << endl;  // avoids extra endl if user doesn't want to use the program again
    
    } while (again == 'y' && again != 'n');
    
    //Exit stage right or left!
    return 0;
}