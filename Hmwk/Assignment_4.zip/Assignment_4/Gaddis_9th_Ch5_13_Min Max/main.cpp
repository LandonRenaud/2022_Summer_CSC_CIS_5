/* 
 * File:   main.cpp
 * Author: Landon Renaud
 * Created on July 12, 2022, 7:32 PM
 * Purpose:  Find the min/max of a series of numbers
 */

//System Libraries
#include <iostream>  //Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    int input,    // the user's input
        min,      // the min value
        max = 0,  // the max value
        n = 0;  // throwaway variable for if statemnt
    
    do {
    
    //Initialize or input i.e. set variable values
    cin >> input;
    if(n < 1) {         // sets the min to the first input of the program
        min = input;
        n++;
    }
    
    //Map inputs -> outputs
    if(input > max && input != -99) max = input; // sets the max to input if input is greater than the current max
    if(min > input && input != -99) min = input; // sets the min to input if input is less than the current min
    
    } while(input != -99);
    //Display the outputs
    cout << "Smallest number in the series is " << min << endl;
    cout << "Largest  number in the series is " << max;

    //Exit stage right or left!
    return 0;
}
