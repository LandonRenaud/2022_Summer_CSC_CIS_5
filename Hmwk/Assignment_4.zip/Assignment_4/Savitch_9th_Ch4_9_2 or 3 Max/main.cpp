/* 
 * File:   main.cpp
 * Author: Landon Renaud
 * Created on July 12, 2022, 
 * Purpose: find max on two and three parameter functions
 */

//System Libraries
#include <iostream>  //Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes
    void TwoParameter(float num1, float num2) { // finds the max of two parameters
        float max;
        if(num1 > num2) max = num1;
        if(num2 > num1) max = num2;
        cout << "Largest number from two parameter function:\n" << max << endl << endl;
    }
    
    void ThreeParameter(float num1, float num2, float num3) { // finds the max out of 3 parameters
        float max;
        if(num1 > num2 && num1 > num3) max = num1;
        if(num2 > num1 && num2 > num3) max = num2;
        if(num3 > num2 && num3 > num2) max = num3;
        cout << "Largest number from three parameter function:\n" << max << endl;
    }


//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    float input1, // the variables to be input as arguments of the functions
          input2,
          input3;
    
    //Initialize or input i.e. set variable values
    cout << "Enter first number:\n\n";
    cin >> input1;
    cout << "Enter Second number:\n\n";
    cin >> input2;
    cout << "Enter third number:\n";
    cin >> input3;
    cout << endl;
    
    //Map inputs -> outputs

    
    
    //Display the outputs
    TwoParameter(input1, input2);           // calls the two parameter max finder
    ThreeParameter(input1, input2, input3); // calls the 3 parameter max finder
    
    //Exit stage right or left!
    return 0;
}