/* 
 * File:   main.cpp
 * Author: Landon Renaud
 * Created on July 12, 2022, 6:24 PM
 * Purpose:  calculate inflation
 */

//System Libraries
#include <iostream>  //Input/Output Library
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    char again;  // used for do-while statement
    float crrntpr,  // current price
          oldpr,    // old price
          irate;    // inflation rate
    
    //Initialize or input i.e. set variable values
    do {
    cout << "Enter current price:\n";
    cin >> crrntpr;
    cout << "Enter year-ago price:\n";
    cin >> oldpr;
    
    
    irate = (crrntpr-oldpr)/oldpr; // finds inflation rate
    irate *= 100;                  // converts rate into a percentage value
    
    cout << fixed << setprecision(2);
    cout << "Inflation rate: " << irate << "%\n\n";
    
    cout << "Again:\n"; // determines if the user wants to use the program again
    cin >> again;
    
    if(again == 'y') cout << endl; // avoids extra endl if user doesn't want to use the program again
    
    } while (again == 'y' && again != 'n');
    
    //Exit stage right or left!
    return 0;
}