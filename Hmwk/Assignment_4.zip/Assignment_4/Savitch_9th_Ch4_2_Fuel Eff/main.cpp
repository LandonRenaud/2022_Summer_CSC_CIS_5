/* 
 * File:   main.cpp
 * Author: Landon Renaud
 * Created on July 12, 2022, 3:48 PM
 * Purpose:  Creation of Template to be used for all
 *           future projects
 */

//System Libraries
#include <iostream>  //Input/Output Library
#include <iomanip>   //IO manipulation library 
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...
const float LTOG = 0.264179; // LTOG stands for liters to gallons

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    char again;  // used for switch statment
    int miles1,     // miles in car 1
        liters1,    // liters used by car 1
        miles2,     // miles in car 2
        liters2;    // liters used in car 2
    float gallons1, // gallons used in car 1
          mpg1,     // miles per gallon of car 1
          gallons2, // gallons used in car 2
          mpg2;     // miles per gallon of car 2
    
    //Initialize or input i.e. set variable values
    do {
    cout << "Car 1\nEnter number of liters of gasoline:\n";
    cin >> liters1;
    cout << "Enter number of miles traveled:\n";
    cin >> miles1;
    
    //Map inputs -> outputs
    gallons1 = liters1*LTOG; // finds the gallons used in car 1
    mpg1 = miles1/gallons1;  // finds miles per gallon of car 1
    
    //Display the outputs
    cout << fixed << setprecision(2);
    cout << "miles per gallon: " << mpg1 << endl << endl;
    
    cout << "Car 2\nEnter number of liters of gasoline:\n";
    cin >> liters2;
    cout << "Enter number of miles traveled:\n";
    cin >> miles2;    
    
    gallons2 = liters2*LTOG; // finds the gallons used in car 2
    mpg2 = miles2/gallons2;  // finds the miles per gallon of car 2
    
    
    cout << "miles per gallon: " << mpg2 << endl << endl;
    
    if(mpg1 > mpg2) {
        cout << "Car 1 is more fuel efficient\n\n";
    } else {
        cout << "Car 2 is more fuel efficient\n\n";
    }
    
    
    
    cout << "Again:\n"; // determines if the user wants to use the program Again
    cin >> again;
    if(again == 'y') cout << endl; // avoids extra endl if user does not want to run the program again
    
    } while (again == 'y' && again != 'n');
    
    //Exit stage right or left!
    return 0;
}