/* 
 * File:   main.cpp
 * Author: Landon Renaud
 * Created on July 12, 2022, 4:36 PM
 * Purpose:  PPrint a pattern of plusses varying in size depending on a user input
 */

//System Libraries
#include <iostream>  //Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    int lines,  // the length of the longest line
        b = 0;  //
    
    //Initialize or input i.e. set variable values
    cin >> lines;
    
    //Map inputs -> outputs
    b = lines-1;
    
    //Display the outputs
    for (int n = 0; n < lines*2; ++n) { // repeats until full pattern is finished
        if(n < lines) {  // switchs direction based on the progress
            for(int a = 0; a < lines-b; ++a) { //increases line length
                cout << "+";
                //cout << b;
            }
                
            cout << endl << endl;
            b--;
            
        } else {
            if(n == lines) {
                b = 0;
            }
            
            for(int a = 0; a < lines-b; ++a) { // decreases line length
                cout << "+";
            }
                
            b++;
            if(n < lines*2-1) { // if statement to avoid an endl at the end of the program
                cout << endl << endl;
            }
        }
            
    }
    
    //Exit stage right or left!
    return 0;
}