/* 
 * File:   main.cpp
 * Author: Landon Renaud
 * Created on July 12, 2022, 3:48 PM
 * Purpose:  Creation of Template to be used for all
 *           future projects
 */

//System Libraries
#include <iostream>  //Input/Output Library
#include <iomanip>   //IO manipulation library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...
const float LTOG = 0.264179; // LTOG stands for liters to gallons

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    char again;  // used for do-while statement
    int miles,   // the miles driven
        liters;  // the liters used
    float gallons,  // the gallons used
          mpg;      // the miles per gallons        
    
    //Initialize or input i.e. set variable values
    do {
    cout << "Enter number of liters of gasoline:\n\n";
    cin >> liters;
    cout << "Enter number of miles traveled:\n\n";
    cin >> miles;
    
    //Map inputs -> outputs
    gallons = liters*LTOG; // converts to gallons
    mpg = miles/gallons;   // finds miles per gallon
    
    //Display the outputs
    cout << fixed << setprecision(2);
    cout << "miles per gallon:\n" << mpg << endl;
    
    cout << "Again:\n";
    cin >> again;
    
    if(again == 'y') cout << endl; // if statement to avoid extra endl if program is ending.
    
    } while (again == 'y' && again != 'n'); // do-while the user inputs y to do again
    
    //Exit stage right or left!
    return 0;
}