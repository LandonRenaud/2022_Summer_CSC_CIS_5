/* 
 * File:   main.cpp
 * Author: Landon Renaud
 * Created on June 30, 2022, 11:19 PM
 * Purpose:  add positives, add negatives, and add both
 */

//System Libraries
#include <iostream>  //Input/Output Library
#include <iomanip>   // the formatting Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    int input,   // the value the user will input, will be reset constantly from the while loop
        sumpos,  // the sum of every positive value
        sumneg,  // the sum of every negative value
        sumall,  // the sum of the negatives and positives
        inptnmb; // the number of inputs by the user
    
    //Initialize or input i.e. set variable values
    inptnmb = 0;

    //Map inputs -> outputs
    cout << "Input 10 numbers, any order, positive or negative\n";
    while (inptnmb<10) {  // will stop repeating at 10 inputs
        cin >> input;
        if (input > 0) {
            sumpos = input + sumpos;
        } else {
            sumneg = input + sumneg;
        }
        inptnmb = inptnmb + 1;  // adds to the count so the while loop can reach 10
    }
    
    sumall = sumneg + sumpos; // finds the total sum
    
    //Display the outputs
    cout << "Negative sum =" << setw(4) << sumneg << endl;
    cout << "Positive sum =" << setw(4) << sumpos << endl;
    cout << "Total sum    =" << setw(4) << sumall;

    //Exit stage right or left! */
    return 0;
} 
