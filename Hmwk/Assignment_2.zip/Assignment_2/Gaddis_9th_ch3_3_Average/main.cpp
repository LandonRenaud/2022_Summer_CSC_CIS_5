/* 
 * File:   main.cpp
 * Author: Landon Renaud
 * Created on June 30, 2022, 7:11 PM
 * Purpose:  Find average of input test scores
 */

//System Libraries
#include <iostream>  //Input/Output Library
#include <iomanip>   //Formating Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    float score1, //the 5 variables for the 5 input test scores
         score2,
         score3,
         score4,
         score5;
    float ave;   //ave short for average, the average score out of the 5 scores
         
    //Initialize or input i.e. set variable values
    cout << "Input 5 numbers to average.\n";
    cin >> score1 >> score2 >> score3 >> score4 >> score5;
    
    //Map inputs -> outputs
    ave = ((score1+score2+score3+score4+score5)/5);
    
    //Display the outputs
    cout << setprecision(1) << fixed << "The average = " << ave;

    //Exit stage right or left!
    return 0;
}