/* 
 * File:   main.cpp
 * Author: Landon Renaud
 * Created on June 30, 2022, 11:11 PM
 * Purpose:  Determine whether a meetingroom's capacity is in violation of fire law regulations
 */

//System Libraries
#include <iostream>  //Input/Output Library
#include <cstdlib>   // standard library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    int cpcty,     // the rooms max capacity
        occpncy,   // number of occupants in the room
        dffrnce;   // the difference between
    
    //Initialize or input i.e. set variable values
    cout << "Input the maximum room capacity and the number of people\n";
    cin >> cpcty >> occpncy;
    
    //Map inputs -> outputs
    dffrnce = abs(cpcty - occpncy);
    
    if (occpncy>cpcty) {
        cout << "Meeting cannot be held.\nReduce number of people by " << dffrnce << " to avoid fire violation.";
    } else {
        cout << "Meeting can be held.\nIncrease number of people by " << dffrnce << " will be allowed without violation.";
    }

    //Exit stage right or left!
    return 0;
}