/* 
 * File:   main.cpp
 * Author: Landon Renaud
 * Created on June 30, 2022, 8:11 PM
 * Purpose:  Calculate how much insurance a user should pay on their home
 */

//System Libraries
#include <iostream>  //Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    float homecst,  // value of user's home
          insrnce;  //cost of insurance 
    
    //Initialize or input i.e. set variable values
    cout << "Insurance Calculator\nHow much is your house worth?\n";
    cin >> homecst;
    
    //Map inputs -> outputs
    insrnce = homecst*0.8;  //insurance is 80% of the home value
    
    //Display the outputs
    cout << "You need $" << insrnce << " of insurance.";

    //Exit stage right or left!
    return 0;
}