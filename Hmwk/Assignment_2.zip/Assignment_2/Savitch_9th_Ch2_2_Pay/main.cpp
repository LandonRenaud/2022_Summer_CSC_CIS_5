/* 
 * File:   main.cpp
 * Author: Landon Renaud
 * Created on June 30, 2022, 10:59 PM
 * Purpose:  Calculate a user's new monthly and yearly salary
 */

//System Libraries
#include <iostream>  //Input/Output Library
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    float payincr = 0.076,  // the rate at which a user's pay will increase
          ynewpay,          // the user's new yearly salary
          mnewpay,          // the user's new monthly salary
          current,          // the user's input salary
          owed;             // the amount of Retroactive pay owed to the user
    
    //Initialize or input i.e. set variable values
    cout << "Input previous annual salary.\n";
    cin >> current;
    //Map inputs -> outputs
    owed = (current*.5)*payincr;
    ynewpay = current*(1+payincr);
    mnewpay = ynewpay/12;
    
    
    //Display the outputs
    cout << fixed << setprecision(2);
    cout << "Retroactive pay    = $" << setw(7) << owed << endl;
    cout << "New annual salary  = $" << setw(7) << ynewpay << endl;
    cout << "New monthly salary = $" << setw(7) << mnewpay;
    
    //Exit stage right or left!
    return 0;
}