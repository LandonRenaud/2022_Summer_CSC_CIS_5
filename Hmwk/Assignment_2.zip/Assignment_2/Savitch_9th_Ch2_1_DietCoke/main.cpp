/* 
 * File:   main.cpp
 * Author: Landon Renaud
 * Created on June 30, 2022, 10:09 PM
 * Purpose:  Calculate how much diet coke a user can drink without dying
 */

//System Libraries
#include <iostream>  //Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    int weight,                     // weight in pounds of user
        canmass = 350,              // mass of a soda can in grams
        maxcans;                    // the maximum amount of cans the user can consume before dying

    float lthldse = 0.14285714,            // the lethal dose ratio of artificial sugar (1:7 sugar:body mass)
          gwght,                    // the weight of the user converted to grams
          maxsgr,                   // the maximum sugar the user can consume before dying
          sgrpcnt = 0.001;          // the percent of artificial sugar in diet coke
        
    //Initialize or input i.e. set variable values
    cout << "Program to calculate the limit of Soda Pop Consumption.\nInput the desired dieters weight in lbs.\n";
    cin >> weight;
    
    //Map inputs -> outputs
    gwght = weight*453.592;  //conversion is 45359.2 grams for a 100 pound person, adjusted to 453.592 for 1 pound)
    maxsgr = gwght*lthldse;
    maxcans = (maxsgr/sgrpcnt)/canmass;
    
    //Display the outputs
    cout << "The maximum number of soda pop cans\nwhich can be consumed is " << maxcans << " cans";

    //Exit stage right or left!
    return 0;
}
