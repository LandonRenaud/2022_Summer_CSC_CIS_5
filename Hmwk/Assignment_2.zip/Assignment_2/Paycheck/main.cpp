/* 
 * File: main.cpp
 * Author: Landon Renaud
 * Created on June 30, 2022, 9:31 PM
 * Purpose:  Calculate a user's gross pay
 */

//System Libraries
#include <iostream>  //Input/Output Library
#include <iomanip>   // formatting library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    float payrt,    // The pay rate of the user
          inhours,  // the hours the user input
          hours,    // the regular hours the user worked
          othours,  // the overtime hours the user worked
          tpay;     // the total pay the user received
    
    //Initialize or input i.e. set variable values
    cout << "This program calculates the gross paycheck.\nInput the pay rate in $'s/hr and the number of hours.\n";
    cin >> payrt >> inhours;
    
    //Map inputs -> outputs
    hours = inhours>40?40:inhours;
    othours = inhours>40?(inhours-hours):0;
    tpay = (hours*payrt) + (othours*payrt*2);
    
    //Display the outputs
    cout << fixed << setprecision(2) << "Paycheck = $" << setw(7) << tpay;

    //Exit stage right or left!
    return 0;
}