/* 
 * File:   main.cpp
 * Author: Landon Renaud
 * Created on June 30, 2022, 7:48 PM
 * Purpose:  Calculate the amount of cookies a user ate and their calories consumed
 */

//System Libraries
#include <iostream>  //Input/Output Library
#include <cmath>
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    float cksate,      // the number of cookies the user ate
          clrspsrvng;  // the number of calories per cookie
    float clrsate,   // the total calories consumed
          nmbrsrvng; //the number of servings aten  
    
    //Initialize or input i.e. set variable values
    cout << "Calorie Counter\nHow many cookies did you eat?\n";
    cin >> cksate;
    clrspsrvng = 300;
    
    //Map inputs -> outputs
    nmbrsrvng = (cksate/4);
    clrsate = (nmbrsrvng*clrspsrvng);
    
    //Display the outputs
    cout << "You consumed " << clrsate << " calories.";

    //Exit stage right or left!
    return 0;
}