/* 
 * File:   main.cpp
 * Author: Landon Renaud
 * Created on June 30, 2022, 8:36 PM
 * Purpose:  Creation of Template to be used for all
 *           future projects
 */

//System Libraries
#include <iostream>  //Input/Output Library
#include <cmath>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...
const float PI = 3.141592;

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    int angl;
    float sinout,    // output of sine
          cosout,    // output of cosine
          tanout,    // output of tangent
          angl2rad;  // The radian value of the user input angle
    
    //Initialize or input i.e. set variable values
    cout << "Calculate trig functions\nInput the angle in degrees.\n";
    cin >> angl;
    
    //Map inputs -> outputs
    angl2rad = angl*PI/180;
    sinout = sin(angl2rad);
    cosout = cos(angl2rad);
    tanout = sinout/cosout;
    
    //Display the outputs
    cout << fixed << setprecision(4);
    cout << "sin(" << angl << ") = " << sinout;
    cout << "\ncos(" << angl << ") = " << cosout;
    cout << "\ntan(" << angl << ") = " << tanout;
    
    //Exit stage right or left!
    return 0;
}