/* 
 * File:   main.cpp
 * Author: Landon Renaud
 * Created on: July 23, 2022, 4:15 PM
 * Purpose: Compare the answer sheet to the key
 *          and grade
 */

// system Libraries
#include <iostream>  //Input/Output Library
#include <fstream>   //File I/O
#include <string.h>    //String Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes
void print(char [], const int);
void read(char [], string&, const int);
int  compare(char [], char [], char [], const int);

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    string key,
           answers,
           score;
    const int SIZE = 20;
    char fileKey[SIZE],
         fileAns[SIZE], 
         results[SIZE];

    float pRight;
    
    //Initialize or input i.e. set variable values
    read(fileKey, key, SIZE);
    read(fileAns, answers, SIZE);
    
    //Score the exam
    pRight=compare(fileKey, fileAns, results, SIZE);
    
    //Display the outputs
    cout << "C/W     "; print(results, SIZE);
    cout << "Percentage Correct = " << pRight/SIZE*100 << "%" << endl;
    
    //Exit stage right or left!
    return 0;
}

void print(char array[], const int SIZE) {
       for( int n = 0; n < SIZE; n++) {
        cout << array[n] << " ";
    }
    cout << endl;
    
}

void read(char array[], string& an, const int SIZE) {
    cin >> an;
    
     for( int n = 0; n < SIZE; n++) {
        cin >> array[n];
    }
    
}

int  compare(char key[], char answers[], char results[], const int SIZE) {
    int pRight = 0;

    for ( int n = 0 ; n < SIZE ; n++) {
        if(key[n] == answers[n] ) {
            results[n] = 'C';
            pRight += 1;
        }
        else results[n] = 'W';
    }
    
    return pRight;
}