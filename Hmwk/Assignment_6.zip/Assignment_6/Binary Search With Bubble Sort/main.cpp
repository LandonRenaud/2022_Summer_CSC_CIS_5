/* 
 * File:   main.cpp
 * Author: Landon Renaud
 * Created on: July 23, 2022, 6:18 PM
 * Purpose:  Binary Search
 */

//System Libraries
#include <iostream>  //Input/Output Library
#include <cstdlib>   //Random Functions
#include <ctime>     //Time Library
#include <iomanip>   //IO manipulation library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes
void fillAry(int [], int);
void prntAry(int [], int, int);
void bublSrt(int [], int);
bool binSrch(int [], int, int, int&);

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    srand(static_cast<unsigned int>(time(0)));
    
    //Declare Variables
    const int SIZE = 100;
    int array[SIZE];
    int indx, val;
    
    //Initialize or input i.e. set variable values
    fillAry(array, SIZE);

    //Sorted List
    bublSrt(array, SIZE);
    
    //Display the outputs
    prntAry(array, SIZE, 10);
    cout << "\nInput the value to find in the array" << endl;
    cin >> val;
    if(binSrch(array, SIZE, val, indx))
        cout << val << " was found at indx = " << indx << endl;

    //Exit stage right or left!
    return 0;
}

// fills in the array with values
void fillAry(int array[], int SIZE) {
    for(int n = 0; n < SIZE; n++) {
        array[n] = (rand()%100)+1;
    }
}

// prints the array
void prntAry(int array[], int SIZE, int linelmt) {
    int n = 0;
    while(n < SIZE) {
        for(int a = 0; a < linelmt; a++) {
            cout << setw(4) << array[n];
            n++;
        }
        cout << endl;
    }
    cout << endl;
}

// Buble sort function
void bublSrt(int array[],int SIZE) {
    int a = SIZE,
        temp;
    bool done;
    
    do {
        done = false;
        
        for(int n = 0; n < a; n++ ) {
            if(array[n] > array[n+1]) { // if an array element is greater than the element after it,
                temp = array[n];        // swaps the two elements
                array[n] = array[n+1];
                array[n+1] = temp;
                
                done = true;
            }
        }
        array[0] = 1;
        a--;
    } while(done);
}

// Binary search function
bool binSrch(int array[], int SIZE, int val, int& indx) {
    int high = SIZE-1,
        low = 0,
        middle,
        count = high;
    indx = 1;
    bool found = false;
    
    do {
        
        middle = (high+low)/2;
        if(array[middle] == val) found = true;
        else if(val < array[middle]) high = middle;
        else if(val > array[middle]) low = middle;
        count--;
        indx = middle; // sets the index to the value's position in the array
    } while(found != true && count != 0);
    
    
    return found;
}