/* 
 * File:   main.cpp
 * Author: Landon Renaud
 * Created on: July 22, 2022, 11:11 PM
 * Purpose:  Linear Search
 */

//System Libraries
#include <iostream>  //Input/Output Library
#include <cstdlib>   //Random Functions
#include <ctime>     //Time Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes
void fillAry(int [], int);
void prntAry(int [], int, int);
bool linSrch(int [], int, int, int&);

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    srand(static_cast<unsigned int>(time(0)));
    
    //Declare Variables
    const int SIZE = 100;
    int array[SIZE];
    int indx,
        val;
    
    //Initialize or input i.e. set variable values
    val = 50;
    fillAry(array,SIZE);
    
    //Display the outputs
    prntAry(array, SIZE, 10);
    if(linSrch(array, SIZE, val, indx))
        cout << val << " was found at indx = " << indx << endl;
    
    //Exit stage right or left!
    return 0;
}

// fills the array
void fillAry(int array[], int SIZE) {
    for(int n = 0; n < SIZE; n++) {
        array[n] = (rand()%100)+1;
    }
}

// prints the array
void prntAry(int array[], int SIZE, int linelmt) {
    int n = 0;
    while(n < SIZE) {
        for(int a = 0; a < linelmt; a++) {
            cout << array[n] << " ";
            n++;
        }
        cout << endl;
    }
    cout << endl;
}

// liinear search function
bool linSrch(int array[], int SIZE, int val, int& indx) {
    bool found = false; // hasn't found the value yet
    for(int n = 0; n < SIZE; n++) {
        if(array[n] == val) {
            found = true; // if the value is found
            indx = n;
            n = SIZE;
        }
    }
    
    return found;
}
