/* 
 * File:   main.cpp
 * Author: Landon Renaud
 * Created on July 23, 2022, 6:19 PM
 * Purpose:
 */

//System Libraries
#include <iostream>
#include <iomanip>
#include <cmath>
#include <ctime>
#include <cstdlib>
using namespace std;

//User Libraries

//Global Constants
//Mathematical/Physics/Conversions, Higher dimensioned arrays
const int COLS = 6;
const float MAXRAND=pow(2,31)-1;

//Function Prototypes
void prob1();
void fillTbl1(int [][COLS],int); // fills the taLble with values
void prntTbl1(const int [][COLS],int); // prints the table


void prob2();
void fillTbl2(int [][COLS],int); // finds the table values
void prntTbl2(const int [][COLS],int); // prints the table


void prob3();
void  init3(int [],int); //Initialize the array
void  print3(int [],int,int); //Print the array
void  revrse3(int [],int); //Reverse the array


void prob4();
void  init4(float [], int, float);//Initialize the array
void  print4(float [], int, int);//Print the array
float avgX(float [], int);//Calculate the Average
float stdX(float [], int);//Calculate the standard deviation


void prob5();
void print5(char [], const int);
void read5(char [], string&, const int);
int  compare(char [], char [], char [], const int);


void prob6();
void fillAry6(int [], int);
void prntAry6(int [], int, int);
bool linSrch(int [], int, int, int&);


void prob7();
void fillAry7(int [], int);
void prntAry7(int [], int, int);
void selSrt(int [], int);
bool binSrch7(int [], int, int, int&);


void prob8();
void fillAry8(int [], int);
void prntAry8(int [], int, int);
void bublSrt(int [], int);
bool binSrch8(int [], int, int, int&);



//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    srand(static_cast<unsigned int>(time(0)));
    //Declare Variables
    char again;
    unsigned short probnum;

    do{
        cout << "Please input a value 1-8: ";
        cin >> probnum;
        
        switch(probnum) {
            case 1: {
                prob1();
                break;
            }
            case 2: {
                prob2();
                break;
            }
            case 3: {
                prob3();
                break;
            }
            case 4: {
                prob4();
                break;
            }
            case 5: {
                prob5();
                break;
            }
            case 6: {
                prob6();
                break;
            }
            case 7: {
                prob7();
                break;
            }
            case 8: {
                prob8();
                break;
            }
            default: {
                cout << "Error, not a value 1-8\n";
            }
        }
    
        cout << "Would you like to run another program? (Y/N)\n";
        cin >> again;
    } while(again == 'Y' || again == 'y'); 
    //Exit stage right
    return 0;
}

// PROBLEM 1 FUNCTIONS
void prob1() {
    //Declare Variables
    const int ROWS = 6;
    int tablSum[ROWS][COLS]; // creates the 2d array
    
    //Initialize or input i.e. set variable values
    fillTbl1(tablSum,ROWS);
    
    //Display the outputs
    prntTbl1(tablSum,ROWS);
    cout << fixed << setprecision(0);
}

void fillTbl1(int tablSum[][COLS], int ROWS) {
    for(int x = 0; x < ROWS; x++) {
        for(int y = 0; y < COLS; y++) {
            tablSum[x][y] = (x+1)+(y+1); 
        }
    }
}

void prntTbl1(const int tablSum[][COLS], int ROWS) {
    int linenum = 0;
    cout << "Think of this as the Sum of Dice Table\n";
    cout << setw(25) << "C o l u m n s\n"
         << setw(6) << "|";
         for(int n = 1; n <= COLS; n++) {
             cout << setw(4) << n;
         }
         cout << endl << "----------------------------------\n";
    for(int x = 0; x < ROWS; x++) { // prints the rows 1 at a time
        ++linenum;
        if(linenum == 1) cout << "   1 |";
        else if(linenum == 2) cout << "R  2 |";
        else if(linenum == 3) cout << "O  3 |";
        else if(linenum == 4) cout << "W  4 |";
        else if(linenum == 5) cout << "S  5 |";
        else if(linenum == 6) cout << "   6 |";
        
        for(int y = 0; y < COLS; y++) {
            cout << setw(4) << tablSum[x][y];
        }
        cout << endl;
    }
    
    
}

// PROBLEM 2 FUNCTIONS
void prob2() {
    //Declare Variables
    const int ROWS = 6;
    int tablSum[ROWS][COLS];
    
    //Initialize or input i.e. set variable values
    fillTbl2(tablSum,ROWS);
    
    //Display the outputs
    prntTbl2(tablSum,ROWS);
}

void fillTbl2(int tablSum[][COLS], int ROWS) {
    for(int x = 0; x < ROWS; x++) {
        for(int y = 0; y < COLS; y++) {
            tablSum[x][y] = (x+1)*(y+1);
        }
    }
}

void prntTbl2(const int tablSum[][COLS], int ROWS) {
    int linenum = 0;
    cout << "Think of this as a Product/Muliplication Table\n";
    cout << setw(25) << "C o l u m n s\n"
         << setw(6) << "|";
         for(int n = 1; n <= COLS; n++) {
             cout << setw(4) << n;
         }
         cout << endl << "----------------------------------\n";
    for(int x = 0; x < ROWS; x++) { // prints the rows 1 at a time
        ++linenum;
        if(linenum == 1) cout << "   1 |";
        else if(linenum == 2) cout << "R  2 |";
        else if(linenum == 3) cout << "O  3 |";
        else if(linenum == 4) cout << "W  4 |";
        else if(linenum == 5) cout << "S  5 |";
        else if(linenum == 6) cout << "   6 |";
        
        for(int y = 0; y < COLS; y++) {
            cout << setw(4) << tablSum[x][y];
        }
        cout << endl;
    }
    
    
}

// PROBLEM 3 FUNCTIONS
void prob3() {
    //Declare Variables
    const int SIZE=50;
    int test[SIZE]; // the array to be reversed
    
    //Initialize or input i.e. set variable values
    init3(test,SIZE);
    
    //Display the outputs
    print3(test,SIZE,10);
    
    //Reverse the Values
    revrse3(test,SIZE);
    
    //Display the outputs
    print3(test,SIZE,10);
}

// fills the array
void init3(int test[], int SIZE) {
    for(int n = 0; n < SIZE; n++) {
        test[n] = (rand()%100)+1;
    }
}
// prints the array
void print3(int test[], int SIZE, int linelmt) {
    int n = 0;
    
    while(n < SIZE) {
        for(int a = 0; a < linelmt; a++) {
            cout << test[n] << " ";
            n++;
        }
        
        cout << endl;
    }
    cout << endl;
}
// swaps the array
void revrse3(int test[], int SIZE) {
    int plchold[SIZE], // place holder array
           a = SIZE-1;
               
    for(int n = 0; n < SIZE; n++) {
        plchold[a--] = test[n]; // sets the place holder array in opposite order

    }
    a = 0;
    
    for(int n = 0; n < SIZE; n++) {
        test[n] = plchold[a++]; // feeds the place holder array back into the original array
    }
}

// PROBLEM 4 FUNCTIONS
void prob4() {
    //Declare Variables
    const int SIZE = 20;
    float test[SIZE];
    
    //Initialize or input i.e. set variable values
    init4(test, SIZE, MAXRAND);
    
    //Display the outputs
    print4(test, SIZE, 5);
    cout << "The average            = " << fixed << setprecision(7) << avgX(test, SIZE) << endl;
    cout << "The standard deviation = " << fixed << setprecision(7) << stdX(test, SIZE) << endl;
}

void  init4(float test[], int SIZE, float MAXRAND) {
    for(int n = 0; n < SIZE; n++) {
        test[n] = (rand()%100)+1;
    }
}

void print4(float test[], int SIZE, int linelmt) {
    int n = 0;
    while(n < SIZE) {
        for(int a = 0; a < linelmt; a++) {
            cout << test[n] << " ";
            n++;
        }
        cout << endl;
    }
    cout << endl;
}

// calculates the average
float avgX(float test[], int SIZE) {
    float ave = 0;
    for(int n = 0; n < SIZE; n++) {
        ave += test[n];
    }
    ave = ave/SIZE;
    return ave;
}

// calculates standard deviation
float stdX(float test[], int SIZE) {
    float std;
    for(int n = 0; n < SIZE; n++) {
        std += (test[n]-avgX(test, SIZE))*(test[n]-avgX(test, SIZE));
        //cout << (test[n]-avgX(test, SIZE))*(test[n]-avgX(test, SIZE)) << endl << std << endl;
    }
    //cout << std << endl;
    std = sqrt(std/(SIZE-1));
    return std;
}

// PROBLEM 5 FUNCTIONS
void prob5() {
    //Declare Variables
    string key,
           answers,
           score;
    const int SIZE = 20;
    char fileKey[SIZE],
         fileAns[SIZE], 
         results[SIZE];

    float pRight;
    
    //Initialize or input i.e. set variable values
    read5(fileKey, key, SIZE);
    read5(fileAns, answers, SIZE);
    
    //Score the exam
    pRight = compare(fileKey, fileAns, results, SIZE);
    
    //Display the outputs
    cout << "C/W     "; print5(results, SIZE);
    cout << "Percentage Correct = " << pRight/SIZE*100 << "%" << endl;
}
 
void print5(char array[], const int SIZE) {
       for( int n = 0; n < SIZE; n++) {
        cout << array[n] << " ";
    }
    cout << endl;
    
}

void read5(char array[], string& an, const int SIZE) {
    cin >> an;
    
     for( int n = 0; n < SIZE; n++) {
        cin >> array[n];
    }
    
}

int  compare(char key[], char answers[], char results[], const int SIZE) {
    int pRight = 0;
    for ( int n = 0 ; n < SIZE ; n++) {
        if(key[n] == answers[n] ) {
            results[n] = 'C';
            pRight += 1;
        }
        else results[n] = 'W';
    }
    
    return pRight;
}

// PROBLEM 6 FUNCTIONS
void prob6() {
    //Declare Variables
    const int SIZE = 100;
    int array[SIZE];
    int indx,
        val;
    
    //Initialize or input i.e. set variable values
    val = 50;
    fillAry6(array,SIZE);
    
    //Display the outputs
    prntAry6(array, SIZE, 10);
    if(linSrch(array, SIZE, val, indx))
        cout << val << " was found at indx = " << indx << endl;
}

// fills the array
void fillAry6(int array[], int SIZE) {
    for(int n = 0; n < SIZE; n++) {
        array[n] = (rand()%100)+1;
    }
}

// prints the array
void prntAry6(int array[], int SIZE, int linelmt) {
    int n = 0;
    while(n < SIZE) {
        for(int a = 0; a < linelmt; a++) {
            cout << array[n] << " ";
            n++;
        }
        cout << endl;
    }
    cout << endl;
}

// linear search function
bool linSrch(int array[], int SIZE, int val, int& indx) {
    bool found = false; // hasn't found the value yet
    for(int n = 0; n < SIZE; n++) {
        if(array[n] == val) {
            found = true; // if the value is found
            indx = n;
            n = SIZE;
        }
    }
    
    return found;
}

// PROBLEM 7 FUNCTIONS
void prob7() {
    //Declare Variables
    const int SIZE=100;
    int array[SIZE];
    int indx = 0, 
        val;
    
    //Initialize or input i.e. set variable values
    fillAry7(array, SIZE);

    //Sorted List
    selSrt(array, SIZE);
    
    //Display the outputs
    prntAry7(array, SIZE, 10);
    cout << "\nInput the value to find in the array" << endl;
    cin >> val;
    if(binSrch7(array, SIZE, val, indx)) cout << val << " was found at indx = " << indx << endl;
}

// fills the array with values
void fillAry7(int array[], int SIZE) {
    for(int n = 0; n < SIZE; n++) {
        array[n] = (rand()%100)+1;
    }
}

// selection sort, sorts the array
void selSrt(int array[],int SIZE) {
    int temp; // a placeholder value for the arrays to swap
        
    for(int n = 0; n < SIZE-1; n++) {
        int minindx = n,
            min = array[n];
        for(int x = n+1; x < SIZE; x++) {
            if(array[x] < min) { 
                min = array[x];
                minindx = x;
            }
        }
        //swaps array values
        temp = array[minindx];
        array[minindx] = array[n];
        array[n] = temp;
    }
}

// prints the array
void prntAry7(int array[], int SIZE, int linelmt) {
    int n = 0;
    while(n < SIZE) {
        for(int a = 0; a < linelmt; a++) {
            cout<< setw(4) << array[n];
            n++;
        }
        cout << endl;
    }
    cout << endl;
}

// binary search function
bool binSrch7(int array[], int SIZE, int val, int& indx) {
    int high = SIZE-1,
        low = 0,
        middle,
        count = high;
    indx = 1;
    bool found = false;
    
    do {
        
        middle = (high+low)/2;
        if(array[middle] == val) found = true;
        else if(val < array[middle]) high = middle;
        else if(val > array[middle]) low = middle;
        count--;
        indx = middle; // sets the index to the value's position in the array
    } while(found != true && count != 0);
    
    
    return found;
}

// PROBLEM 8 FUNCTIONS
void prob8() {
    //Declare Variables
    const int SIZE = 100;
    int array[SIZE];
    int indx, val;
    
    //Initialize or input i.e. set variable values
    fillAry8(array, SIZE);

    //Sorted List
    bublSrt(array, SIZE);
    
    //Display the outputs
    prntAry8(array, SIZE, 10);
    cout << "\nInput the value to find in the array" << endl;
    cin >> val;
    if(binSrch8(array, SIZE, val, indx))
        cout << val << " was found at indx = " << indx << endl;
}

// fills in the array with values
void fillAry8(int array[], int SIZE) {
    for(int n = 0; n < SIZE; n++) {
        array[n] = (rand()%100)+1;
    }
}

// prints the array
void prntAry8(int array[], int SIZE, int linelmt) {
    int n = 0;
    while(n < SIZE) {
        for(int a = 0; a < linelmt; a++) {
            cout << setw(4) << array[n];
            n++;
        }
        cout << endl;
    }
    cout << endl;
}

// Buble sort function
void bublSrt(int array[],int SIZE) {
    int a = SIZE,
        temp;
    bool done;
    
    do {
        done = false;
        
        for(int n = 0; n < a; n++ ) {
            if(array[n] > array[n+1]) { // if an array element is greater than the element after it,
                temp = array[n];        // swaps the two elements
                array[n] = array[n+1];
                array[n+1] = temp;
                
                done = true;
            }
        }
        array[0] = 1;
        a--;
    } while(done);
}

// Binary search function
bool binSrch8(int array[], int SIZE, int val, int& indx) {
    int high = SIZE-1,
        low = 0,
        middle,
        count = high;
    indx = 1;
    bool found = false;
    
    do {
        
        middle = (high+low)/2;
        if(array[middle] == val) found = true;
        else if(val < array[middle]) high = middle;
        else if(val > array[middle]) low = middle;
        count--;
        indx = middle; // sets the index to the value's position in the array
    } while(found != true && count != 0);
    
    
    return found;
}