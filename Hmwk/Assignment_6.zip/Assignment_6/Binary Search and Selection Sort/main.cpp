/* 
 * File:   main.cpp
 * Author: Landon Renaud
 * Created on: July 22, 2022, 11:13 PM
 * Purpose:  Binary Search
 */

//System Libraries
#include <iostream>  //Input/Output Library
#include <cstdlib>   //Random Functions
#include <ctime>     //Time Library
#include <iomanip>   // io manipulation library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes
void fillAry(int [], int);
void prntAry(int [], int, int);
void selSrt(int [], int);
bool binSrch(int [], int, int, int&);

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    srand(static_cast<unsigned int>(time(0)));
    
    //Declare Variables
    const int SIZE=100;
    int array[SIZE];
    int indx = 0, 
        val;
    
    //Initialize or input i.e. set variable values
    fillAry(array, SIZE);

    //Sorted List
    selSrt(array, SIZE);
    
    //Display the outputs
    prntAry(array, SIZE, 10);
    cout << "\nInput the value to find in the array" << endl;
    cin >> val;
    if(binSrch(array, SIZE, val, indx)) cout << val << " was found at indx = " << indx << endl;

    //Exit stage right or left!
    return 0;
}

// fills the array with values
void fillAry(int array[], int SIZE) {
    for(int n = 0; n < SIZE; n++) {
        array[n] = (rand()%100)+1;
    }
}

// selection sort, sorts the array
void selSrt(int array[],int SIZE) {
    int temp; // a placeholder value for the arrays to swap
        
    for(int n = 0; n < SIZE-1; n++) {
        int minindx = n,
            min = array[n];
        for(int x = n+1; x < SIZE; x++) {
            if(array[x] < min) { 
                min = array[x];
                minindx = x;
            }
        }
        //swaps array values
        temp = array[minindx];
        array[minindx] = array[n];
        array[n] = temp;
    }
}

// prints the array
void prntAry(int array[], int SIZE, int linelmt) {
    int n = 0;
    while(n < SIZE) {
        for(int a = 0; a < linelmt; a++) {
            cout<< setw(4) << array[n];
            n++;
        }
        cout << endl;
    }
    cout << endl;
}

// binary search function
bool binSrch(int array[], int SIZE, int val, int& indx) {
    int high = SIZE-1,
        low = 0,
        middle,
        count = high;
    indx = 1;
    bool found = false;
    
    do {
        middle = (high+low)/2;
        if(array[middle] == val) found = true;
        else if(val < array[middle]) high = middle;
        else if(val > array[middle]) low = middle;
        count--;
        indx = middle; // sets the index to the position in the array
    } while(found != true && count != 0);
    
    return found;
}