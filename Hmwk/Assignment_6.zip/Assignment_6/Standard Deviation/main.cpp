/* 
 * File:   main.cpp
 * Author: Landon Renaud
 * Created on: July 22, 2022, 11:32 PM
 * Purpose: find the standard deviation of an array
 */

//System Libraries
#include <iostream>  //Input/Output Library
#include <cstdlib>   //Srand
#include <ctime>     //Time to set random number seed
#include <cmath>     //Math Library
#include <iomanip>   //Format Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...
const float MAXRAND=pow(2,31)-1;

//Function Prototypes
void  init(float [], int, float);//Initialize the array
void  print(float [], int, int);//Print the array
float avgX(float [], int);//Calculate the Average
float stdX(float [], int);//Calculate the standard deviation

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    srand(static_cast<unsigned>(time(0)));
    
    //Declare Variables
    const int SIZE = 20;
    float test[SIZE];
    
    //Initialize or input i.e. set variable values
    init(test, SIZE, MAXRAND);
    
    //Display the outputs
    print(test, SIZE, 5);
    cout << "The average            = " << fixed << setprecision(7) << avgX(test, SIZE) << endl;
    cout << "The standard deviation = " << fixed << setprecision(7) << stdX(test, SIZE) << endl;

    //Exit stage right or left!
    return 0;
}

// fills the array
void  init(float test[], int SIZE, float MAXRAND) {
    for(int n = 0; n < SIZE; n++) {
        test[n] = (rand()%100)+1;
    }
}

// print function for the array
void print(float test[], int SIZE, int linelmt) {
    int n = 0;
    while(n < SIZE) {
        for(int a = 0; a < linelmt; a++) {
            cout << test[n] << " ";
            n++;
        }
        cout << endl;
    }
    cout << endl;
}

// calculates the average
float avgX(float test[], int SIZE) {
    float ave = 0;
    for(int n = 0; n < SIZE; n++) {
        ave += test[n];
    }
    ave = ave/SIZE;
    return ave;
}

// calculates standard deviation
float stdX(float test[], int SIZE) {
    float std;
    for(int n = 0; n < SIZE; n++) {
        std += (test[n]-avgX(test, SIZE))*(test[n]-avgX(test, SIZE));
        //cout << (test[n]-avgX(test, SIZE))*(test[n]-avgX(test, SIZE)) << endl << std << endl;
    }
    //cout << std << endl;
    std = sqrt(std/(SIZE-1));
    return std;
}