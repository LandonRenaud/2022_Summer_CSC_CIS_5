/* 
 * File:   main.cpp
 * Author: Landon Renaud
 * Created on July 8, 2022, 12:41 AM
 * Purpose:  Calculate a user's monthly isp bill
 */

//System Libraries
#include <iostream>  //Input/Output Library
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    char plannmb;  // the plan the user is using
    float hours,    // the hours the user has spent
          othours;  // the hours the user has spent over the time limit
    
    // Package A
    float rateA = 9.95,   // hourly rate of plan a
          maxhrsA = 10,   // max hours allowed on plan a
          adhourA = 2.00; // the rate per additional hour used
    
    // Package B
    float rateB = 14.95,  // hourly rate of plan b
          maxhrsB = 20,   // max hours allowed on plan b
          adhourB = 1.00; // the rate per additional hour used
    
    // Package C
    float rateC = 19.95;  // hourly rate of plan c
    
    float bill;
    
    //Initialize or input i.e. set variable values
    cout << "ISP Bill\nInput Package and Hours\n";
    cin >> plannmb >> hours;
    
    //Map inputs -> outputs
    switch(plannmb) {
        case 'A': 
                  othours = hours>maxhrsA? (hours-maxhrsA):0;
                  bill = rateA + (othours*adhourA);
                  break;
        case 'B': 
                  othours = hours>maxhrsB? (hours-maxhrsB):0;
                  bill = rateB + (othours*adhourB);
                  break;
        case 'C': 
                  bill = rateC;
                  break;
    }
    
    //Display the outputs
    cout << fixed << setprecision(2) << "Bill = $ " << bill;
    
    //Exit stage right or left!
    return 0;
}
