/* 
 * File:   main.cpp
 * Author: Landon Renaud
 * Created on July 7, 2022, 10:28 PM
 * Purpose:  keep score on a rock paper scissors game
 */

//System Libraries
#include <iostream>  //Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    string in1, in2;
    
    //Initialize or input i.e. set variable values
    cout << "Rock Paper Scissors Game\nInput Player 1 and Player 2 Choices\n";
    cin >> in1 >> in2;
    
    //Map inputs -> outputs and display
    // converts lowercase to uppercase
    if(in1 == "p") in1 = "P";
    if(in1 == "s") in1 = "S";
    if(in1 == "r") in1 = "R";
    if(in2 == "p") in2 = "P";
    if(in2 == "s") in2 = "S";
    if(in2 == "r") in2 = "R";
    
    // reads inputs and determines who wins
    if((in1 == "P" && in2 == "S") || (in1 == "S" && in2 == "P")) { //determines between paper and scissors
        cout << "Scissors cuts paper.";
        
    } else if((in1 == "P" && in2 == "R") || (in1 == "R" && in2 == "P")) {
        cout << "Paper covers rock.";
        
    } else if((in1 == "S" && in2 == "R") || (in1 == "R" && in2 == "S")) {
        cout << "Rock breaks scissors.";
        
    } else {
        cout << "Nobody wins.";
    }

    //Exit stage right or left!
    return 0;
}