/* 
 * File:   main.cpp
 * Author: Landon Renaud
 * Created on July 7, 2022, 9:26 PM
 * Purpose:  Convert Roman Numerals to standard numbers
 */

//System Libraries
#include <iostream>  //Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    int number, // the arabic number the user will input
        thous,  // the number of 1000s
        hund,   // the number of 100s
        tens,   // the number of 10s
        ones;   // the number of 1s
    string romanN; // the roman numeral to be output
    
    //Initialize or input i.e. set variable values
    cout << "Arabic to Roman numeral conversion.\nInput the integer to convert.\n";
    cin >> number;
    
    //Map inputs -> outputs
    
    if(number>3000 || number<1000) {             // Filters out inputs which are
        cout << number << " is Out of Range!";   // out of range
        return 0;
    }
    
    thous = number/1000;
    number = number - thous*1000;
    hund = number/100;
    number = number - hund*100;
    tens = number/10;
    number = number - tens*10;
    ones = number;
    
    // Add the thousands
    switch(thous) {
        case 3: romanN = "MMM";
                break;
        case 2: romanN = romanN + "MM";
                break;
        case 1: romanN = romanN + "M";
                break;
    }
    
    // Add the hundreds
    switch(hund) {
        case 9: romanN = romanN + "CM";
                break;
        case 8: romanN = romanN + "DCCC";
                break;
        case 7: romanN = romanN + "DCC";
                break;
        case 6: romanN = romanN + "DC";
                break;
        case 5: romanN = romanN + "D";
                break;
        case 4: romanN = romanN + "CD";
                break;
        case 3: romanN = romanN + "CCC";
                break;
        case 2: romanN = romanN + "CC";
                break;
        case 1: romanN = romanN + "C";
                break;
    }
    
    // Add the tens
    switch(tens) {
        case 9: romanN = romanN + "XC";
                break;
        case 8: romanN = romanN + "LXX";
                break;
        case 7: romanN = romanN + "LXX";
                break;
        case 6: romanN = romanN + "LX";
                break;
        case 5: romanN = romanN + "L";
                break;
        case 4: romanN = romanN + "XL";
                break;
        case 3: romanN = romanN + "XXX";
                break;
        case 2: romanN = romanN + "XX";
                break;
        case 1: romanN = romanN + "X";
                break;
    }
    
    // Add the ones
    switch(tens) {
        case 9: romanN = romanN + "IX";
                break;
        case 8: romanN = romanN + "VIII";
                break;
        case 7: romanN = romanN + "VII";
                break;
        case 6: romanN = romanN + "VI";
                break;
        case 5: romanN = romanN + "V";
                break;
        case 4: romanN = romanN + "IV";
                break;
        case 3: romanN = romanN + "II";
                break;
        case 2: romanN = romanN + "II";
                break;
        case 1: romanN = romanN + "I";
                break;
    }
    
    number = thous*1000 + hund*100 + tens*10 + ones; // recreate the input number
    
    //Display the outputs
    cout << number << " is equal to " << romanN;
    
    //Exit stage right or left!
    return 0;
}