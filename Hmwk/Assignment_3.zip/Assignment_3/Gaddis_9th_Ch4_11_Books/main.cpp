/* 
 * File:   main.cpp
 * Author: Landon Renaud
 * Created on July 8, 2022, 1:31 AM
 * Purpose:  Display the amount of points rewarded for a user's books
 */

//System Libraries
#include <iostream>  //Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    int booknum, points;
    //Initialize or input i.e. set variable values
    cout << "Book Worm Points\nInput the number of books purchased this month.\n";
    cin >> booknum;
    cout << "Books purchased =  " << booknum << endl;
    
    //Map inputs -> outputs
    switch(booknum) {
        case 1:
                points = 5;
                break;
        case 2:
                points = 15;
                break;
        case 3: 
                points = 30;
                break;
        default: 
                points = 60;
    }
    
    //Display the outputs
    cout << "Points earned   = " << points;
    //Exit stage right or left!
    return 0;
}