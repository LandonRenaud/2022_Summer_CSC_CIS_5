/* 
 * File:   main.cpp
 * Author: Landon Renaud
 * Created on July 8, 2022, 2:16 PM
 * Purpose:  Rank racers
 */

//System Libraries
#include <iostream>  //Input/Output Library
#include <iomanip>   // Io manipulation library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    string name1, name2, name3;  // The names of the racers
    int time1, time2, time3;     // The times of the racers
    
    //Initialize or input i.e. set variable values        
    
    cout << "Race Ranking Program\nInput 3 Runners\n"; // record names and times
    cin >> name1 >> time1;
    cin >> name2 >> time2;
    cin >> name3 >> time3;
    
    //Map inputs -> outputs
    cout << "Their names, then their times\n";
    
    if(time1 < 0 || time2 < 0 || time3 < 0) {       // Check if times are less than 0
        cout << "Only positive values are allowed"; // Spits out an error and ends program if times are less than 0
        return 0;
    }
    
    // Oders the times and prints the names and times in order.
    if(time1<time2 && time1<time3) {
        cout << name1 << "\t" << setw(3) << time1 << endl;
        
        if(time2<time3) {
            cout << name2 << "\t" << setw(3) << time2 << endl;
            cout << name3 << "\t" << setw(3) << time3;
            
        } else if(time3<time2) {
            cout << name3 << "\t" << setw(3) << time3 << endl;
            cout << name2 << "\t" << setw(3) << time2;
            
        }
    } else if(time2<time1 && time2<time3) {
        cout << name2 << "\t" << setw(3) << time2 << endl;
        
        if(time1<time3) {
            cout << name1 << "\t" << setw(3) << time1 << endl;
            cout << name3 << "\t" << setw(3) << time3;
            
        } else if(time3<time1) {
            cout << name3 << "\t" << setw(3) << time3 << endl;
            cout << name1 << "\t" << setw(3) << time1;
        }
    } else if(time3<time1 && time3<time2) {
        cout << name3 << "\t" << setw(3) << time3 << endl;
        
        if(time1<time2) {
            cout << name1 << "\t" << setw(3) << time1 << endl;
            cout << name2 << "\t" << setw(3) << time2;
            
        } else if(time2<time1) {
            cout << name2 << "\t" << setw(3) << time2 << endl;
            cout << name1 << "\t" << setw(3) << time1;
            
        }
    }
    
    //Exit stage right or left!
    return 0;
}