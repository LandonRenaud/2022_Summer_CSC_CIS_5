/* 
 * File:   main.cpp
 * Author: Landon Renaud
 * Created on July 7, 2022, 8:49 PM
 * Purpose:  Sort user input names into alphabetical order
 */

//System Libraries
#include <iostream>  //Input/Output Library
#include <string>    //String Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    string name[3],  // The name to be read
           placehd;  // placeholder variable
           
    
    //Initialize or input i.e. set variable values
    cout << "Sorting Names\nInput 3 names\n";
    for(int n = 0; n < 3; ++n) {
        cin >> name[n];            // records the 3 names
    }
    //Map inputs to outputs
    for(int num1 = 0; num1 < 3; ++num1) {
        
        for(int num2 = num1 + 1; num2 < 3; ++num2) { //bubble algorithm for sorting
            
            if(name[num1]>name[num2]) {
                placehd = name[num1];
                name[num1] = name[num2];
                name[num2] = placehd;
                
            }
        }
    
                   
    //Display outputs
            cout << name[num1];
            
        if(num1 < 2) {
            cout << endl;
        }
        
        
    }
    //Exit stage right or left!
    return 0;
}