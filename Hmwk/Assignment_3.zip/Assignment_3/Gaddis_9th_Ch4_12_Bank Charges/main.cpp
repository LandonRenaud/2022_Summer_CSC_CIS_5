/* 
 * File:   main.cpp
 * Author: Landon Renaud
 * Created on July 8, 2022, 4:39 PM
 * Purpose:  Calculate the total charges on a bank account for a given month
 */

//System Libraries
#include <iostream>  // Input/Output Library
#include <iomanip>   // The io management library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    int chknmb;    // The number of checks written
    
    float bal,     // The bank balance
          chkfee,  // The total fee 
          chkfees, // The fee per check based on # of checks
          tfees,   // The total fees owed
          newbal,  // The new balance after fees
          lowbal;  // Variable to be set based on current bank balance
    
    //Initialize or input i.e. set variable values
    cout << "Monthly Bank Fees\nInput Current Bank Balance and Number of Checks\n";
    cin >> bal >> chknmb;
    
    //Map inputs -> outputs
    if(bal<0) {
        cout << "Warning: Your bank account is overdrawn!";
        return 0;
    }
    
    if(chknmb<20) {                       // sets check fees
        chkfees = 0.10;
    } else if (chknmb>=20 && chknmb<40) {
        chkfees = 0.08;
    } else if (chknmb>=40 && chknmb<60) {
        chkfees = 0.06;
    } else if (chknmb>=60) {
        chkfees = 0.04;
    }
    
    if(bal<400) lowbal = 15;  //sets lowbal to 15 if bal is less than 400
    else lowbal = 0;
    
    chkfee = chkfees*chknmb;
    (bal<400)? (tfees = (chkfee + 10 + lowbal)):(tfees = (chkfee + 10)); // adds $15 to total fees if the balance was less than $400
    newbal = bal-tfees;
    
    //Display the outputs
    cout << fixed << setprecision(2);
    cout << "Balance     $" << setw(9) << bal << endl;
    cout << "Check Fee   $" << setw(9) << chkfee << endl;
    cout << "Monthly Fee $" << setw(9) << 10.00 << endl;
    cout << "Low Balance $" << setw(9) << lowbal << endl;
    cout << "New Balance $" << setw(9) << newbal;
    
    //Exit stage right or left!
    return 0;
}