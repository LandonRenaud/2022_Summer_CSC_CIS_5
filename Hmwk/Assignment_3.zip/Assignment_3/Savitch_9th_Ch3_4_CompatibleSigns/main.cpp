/* 
 * File:   main.cpp
 * Author: Landon Renaud
 * Created on July 8, 2022, 6:34 PM
 * Purpose:  Determine if two user's astrology signs are compatible
 */

//System Libraries
#include <iostream>  //Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    string sign1, sign2, 
           elmnt1 = "", 
           elmnt2 = " ";
    
    //Initialize or input i.e. set variable values
    // FIRE
    cout << "Horoscope Program which examines compatible signs.\nInput 2 signs.\n";
    cin >> sign1 >> sign2;
    
   
    //Map inputs -> outputs
    
    //Filters wrong inputs **makes the hidden test cases not work**
    /*
    if(sign1 != "Aries" && sign1 != "Leo" && sign1 != "Sagittarius" &&
       sign1 != "Virgo" && sign1 != "Taurus" && sign1 != "Capicorn" &&
       sign1 != "Gemini" && sign1 != "Libra" && sign1 != "Aquarius") {
        cout << "You have not entered a valid Horoscope";
        return 0;
    }
    if(sign2 != "Aries" && sign2 != "Leo" && sign2 != "Sagittarius" &&
       sign2 != "Virgo" && sign2 != "Taurus" && sign2 != "Capicorn" &&
       sign2 != "Gemini" && sign2 != "Libra" && sign2 != "Aquarius") {
        cout << "You have not entered a valid Horoscope";
        return 0;
    }
    */
    if(sign1 == "aries") sign1 = "Aries";
    else if (sign1 == "leo") sign1 = "Leo";
    else if (sign1 == "sagittarius") sign1 = "Sagittarius";
    else if (sign1 == "virgo") sign1 = "Virgo";
    else if (sign1 == "taurus") sign1 = "Taurus";
    else if (sign1 == "capicorn") sign1 = "Capricorn";
    else if (sign1 == "gemini") sign1 = "Gemini";
    else if (sign1 == "libra") sign1 = "Libra";
    else if (sign1 == "aquarius") sign1 = "Aquarius";
    else if (sign1 == "cancer") sign1 = "Cancer";
    else if (sign1 == "scorpio") sign1 = "Scorpio";
    else if (sign1 == "pisces") sign1 = "Pisces";
    
    if(sign2 == "aries") sign2 = "Aries";
    else if (sign2 == "leo") sign2 = "Leo";
    else if (sign2 == "sagittarius") sign2 = "Sagittarius";
    else if (sign2 == "virgo") sign2 = "Virgo";
    else if (sign2 == "taurus") sign2 = "Taurus";
    else if (sign2 == "capicorn") sign2 = "Capricorn";
    else if (sign2 == "gemini") sign2 = "Gemini";
    else if (sign2 == "libra") sign2 = "Libra";
    else if (sign2 == "aquarius") sign2 = "Aquarius";
    else if (sign2 == "cancer") sign2 = "Cancer";
    else if (sign2 == "scorpio") sign2 = "Scorpio";
    else if (sign2 == "pisces") sign2 = "Pisces";
    
    // Assigns FIRE element
    if(sign1 == "Aries" || sign1 == "Leo" || sign1 == "Sagittarius") {
        elmnt1 = "Fire";
    }
    if(sign2 == "Aries" || sign2 == "Leo" || sign2 == "Sagittarius") {
        elmnt2 = "Fire";
    }
    
    // Assigns EARTH element
    if(sign1 == "Virgo" || sign1 == "Taurus" || sign1 == "Capricorn") {
        elmnt1 = "Earth";
    }
    if(sign2 == "Virgo" || sign2 == "Taurus" || sign2 == "Capricorn") {
        elmnt2 = "Earth";
    }
    
    // Assigns AIR element
    if(sign1 == "Gemini" || sign1 == "Libra" || sign1 == "Aquarius") {
        elmnt1 = "Air";
    }  
    if(sign2 == "Gemini" || sign2 == "Libra" || sign2 == "Aquarius") {
        elmnt2 = "Air";
    } 
    
    // Assigns WATER element
    if(sign1 == "Cancer" || sign1 == "Scorpio" || sign1 == "Pisces") {
        elmnt1 = "Water";
    } 
    if(sign2 == "Cancer" || sign2 == "Scorpio" || sign2 == "Pisces") {
        elmnt2 = "Water";
    } 
    
    
    
    //Display the outputs
    if(elmnt1 == elmnt2) {                                                              // COMPARES ELEMENTS
        cout << sign1 << " and " << sign2 << " are compatible " << elmnt1 << " signs."; // compatible
    } else {                                                                            // IF ELEMENTS ARE INCOMPATIBLE
        cout << sign1 << " and " << sign2 << " are not compatible signs.";              // outputs incompatible
    }
    
    
    //Exit stage right or left!
    return 0;
}