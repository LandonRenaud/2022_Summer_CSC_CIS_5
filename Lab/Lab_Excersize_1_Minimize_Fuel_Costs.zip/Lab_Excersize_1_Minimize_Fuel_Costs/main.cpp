/* 
 * File:   main.cpp
 * Author: Landon Renaud
 * Created on June 29, 2022, 11:23 AM
 * Purpose: Calculate which gas station (including miles to gas station) is the cheapest
 */

//System Libraries
#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

//User Libraries

//Global Constants
//Mathematical/Physics/Conversions, Higher dimensioned arrays

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    
    //Declare Variables
    //car variables
    float gage, gasrqrd; // gasrqrd is for the gas required [(1-gage)*tnksize] = gasrqrd. For gage = 75.00%,  the gasrqrd should be 5.5 gallons 
    int tnksize, mpg;
    
    //Gas Station 1 variables
    float price1,  // gas price at gas station 1
          dstnce1, // distance to gas station 1
          cost1,   // cost to fill up at gas station 1
          ttldst1, // total distance traveled to and from gas station 1
          dstcst1, // the cost to drive to and from gas station 1
          ttlcst1, // the total cost of the trip, including cost of gas used to drive to the station
          ttlppg1; // the total price per gallon of the trip
    
    //Gas Station 2 variables, all variables represent the same as Gas Station 1, but are labeled 2 for gas station 2
    float price2,
          dstnce2,
          cost2,
          ttldst2,
          dstcst2,
          ttlcst2,
          ttlppg2;
    //Initialize Variables
    //Input for Car values
    cout << "What how full is your tank (please give a percentage, omit the percent symbol %)?\n";
    cin >> gage;
    cout << "Your tank is " << gage << "% full.\n";
    cout << "How many gallons does your tank hold?\n";
    cin >> tnksize;
    cout << "Your tank holds " << tnksize << " gallons.\n";
    cout << "What is the gas mileage of your car (please give miles per gallon)\n";
    cin >> mpg;
    cout << "Your car performs at " << mpg << " miles per gallon.";
    
    cout << "\n\nThere are two gas stations near you. In order to determine which station is the best option, please input the following information (do not input units):";
    //Input for 1st gas station variables
    cout << "\nWhat is the distance in miles from here to the first gas station? ";
    cin >> dstnce1;
    cout << "What is the price per gallon the gas station charges? ";
    cin >> price1;
    //Input for 2nd gas station variables
    cout << "\n\nSecond Gas Station:\nWhat is the distance in miles from here to the second gas station? ";
    cin >> dstnce2;
    cout << "What is the price per gallon the gas station charges? ";
    cin >> price2;

    //Map inputs to outputs -> The Process
    gage = gage/100;
    gasrqrd = (1-gage)*tnksize;
    
    //Calculations for station 1://
    cost1 = gasrqrd*price1;
    ttldst1 = dstnce1*2;
    dstcst1 = (ttldst1/mpg)*price1;
    ttlcst1 = cost1 + dstcst1;
    ttlppg1 = ttlcst1/(gasrqrd);
    
    //Calculations for station 2://
    cost2 = gasrqrd*price2;
    ttldst2 = dstnce2*2;
    dstcst2 = (ttldst2/mpg)*price2;
    ttlcst2 = cost2 + dstcst2;
    ttlppg2 = ttlcst2/(gasrqrd);

    //Display Results
    cout << "\n\nGas Station 1:";
    cout << "\nThe cost for " << gasrqrd << " gallons will be $" << cost1 << ".";
    cout << "\nTo fill up at the second station, it will be a " << ttldst1 << " mile round trip, and the cost of gas for driving that distance will be $" << dstcst1 << ".";
    cout << "\nIncluding the cost of the gas used to drive to the station, the total cost will be $" << ttlcst1 << ".";

    cout << "\nGas Station 2:";
    cout << "\nThe cost for " << gasrqrd << " gallons will be $" << cost2 << ".";
    cout << "\nTo fill up at the first station, it will be a " << ttldst2 << " mile round trip, and the cost of gas for driving that distance will be $" << setprecision(9) << dstcst2 << ".";
    cout << "\nIncluding the cost of the gas used to drive to the station, the total cost will be $" << ttlcst2 << ".";
    
    cout << "\n\n" << setprecision(9);
    cout << "\nThe cost per gallon at gas station 1 will be $" << ttlppg1 << " per gallon.";
    cout << "\nThe cost per gallon at gas station 2 will be $" << ttlppg2 << " per gallon.";
    
    //Exit stage right
    return 0;
}

