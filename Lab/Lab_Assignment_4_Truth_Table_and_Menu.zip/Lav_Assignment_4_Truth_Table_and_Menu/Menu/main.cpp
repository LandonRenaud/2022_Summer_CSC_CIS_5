/* 
 * File:   main.cpp
 * Author: Landon Renaud
 * Created on July 8th, 2022, 10:41 AM
 * Purpose:  Basic Menu for Homework and Exams
 */

//System Libraries
#include <iostream>   //Input/Output Library
#include <string>     //String Library
#include <iomanip>    //Io manipulation library
using namespace std;  //STD Name-space where Library is compiled

//User Libraries

//Global Constants not Variables
//Math/Physics/Science/Conversions/Dimensions

//Function Prototypes

//Code Begins Execution Here with function main
int main(int argc, char** argv) {
    //Set random number seed once here
    
    //Declare variables here
    int choose;//Choose a problem
    
    //Initialize variables here
    do{
        //List of Problems which can be run by the program
        cout<<"Choose from the following Menu Items"<<endl;
        cout<<"Problem 0"<<endl;
        cout<<"Problem 1"<<endl;
        cout<<"Problem 2"<<endl;
        cout<<"Etc......"<<endl;
        cout<<"10 or greater, all negatives to exit"<<endl;
        cin>>choose;
        
        switch(choose){
            case 0: {
                //Declare Variables
                string name[3],  // The name to be read
                       placehd;  // placeholder variable
           
    
                //Initialize or input i.e. set variable values
                cout << "Sorting Names\nInput 3 names\n";
                for(int n = 0; n < 3; ++n) {
                    cin >> name[n];            // records the 3 names
                }
                    
                //Map inputs to outputs
                for(int num1 = 0; num1 < 3; ++num1) {
        
                    for(int num2 = num1 + 1; num2 < 3; ++num2) { //bubble algorithm for sorting
            
                        if(name[num1]>name[num2]) {
                            placehd = name[num1];
                            name[num1] = name[num2];
                            name[num2] = placehd;
                
                        }
                    }
    
                   
                //Display outputs
                    cout << name[num1];
            
                    if(num1 < 2) {
                        cout << endl;
                    }
        
        
                }
                cout << endl << endl;
                break;
            }
            case 1: {
                //Declare Variables
                int booknum, points;
                
                //Initialize or input i.e. set variable values
                cout << "Book Worm Points\nInput the number of books purchased this month.\n";
                cin >> booknum;
                cout << "Books purchased =  " << booknum << endl;
    
                //Map inputs -> outputs
                switch(booknum) {
                    case 1:
                        points = 5;
                        break;
                    case 2:
                        points = 15;
                        break;
                    case 3: 
                        points = 30;
                        break;
                    default: 
                        points = 60;
                }
    
                //Display the outputs
                cout << "Points earned   = " << points;
                
                
                cout << endl << endl;
                break;
            }
            case 2: {
                //Declare Variables
                int chknmb;    // The number of checks written
    
                float bal,     // The bank balance
                      chkfee,  // The total fee 
                      chkfees, // The fee per check based on # of checks
                      tfees,   // The total fees owed
                      newbal,  // The new balance after fees
                      lowbal;  // Variable to be set based on current bank balance
    
                //Initialize or input i.e. set variable values
                cout << "Monthly Bank Fees\nInput Current Bank Balance and Number of Checks\n";
                cin >> bal >> chknmb;
    
                //Map inputs -> outputs
                if(bal<0) {
                    cout << "Warning: Your bank account is overdrawn!";
                    break;
                }
    
                if(chknmb<20) {                       // sets check fees
                    chkfees = 0.10;
                } else if (chknmb>=20 && chknmb<40) {
                    chkfees = 0.08;
                } else if (chknmb>=40 && chknmb<60) {
                    chkfees = 0.06;
                } else if (chknmb>=60) {
                    chkfees = 0.04;
                }
    
                if(bal<400) lowbal = 15;  //sets lowbal to 15 if bal is less than 400
                else lowbal = 0;
    
                chkfee = chkfees*chknmb;
                (bal<400)? (tfees = (chkfee + 10 + lowbal)):(tfees = (chkfee + 10)); // adds $15 to total fees if the balance was less than $400
                newbal = bal-tfees;
    
                //Display the outputs
                cout << fixed << setprecision(2);
                cout << "Balance     $" << setw(9) << bal << endl;
                cout << "Check Fee   $" << setw(9) << chkfee << endl;
                cout << "Monthly Fee $" << setw(9) << 10.00 << endl;
                cout << "Low Balance $" << setw(9) << lowbal << endl;
                cout << "New Balance $" << setw(9) << newbal;
    
    
                
                cout << endl << endl;
                break;
            }
            case 3: {
                //Declare Variables
                string name1, name2, name3;  // The names of the racers
                int time1, time2, time3;     // The times of the racers
    
                //Initialize or input i.e. set variable values        
    
                cout << "Race Ranking Program\nInput 3 Runners\n"; // record names and times
                cin >> name1 >> time1;
                cin >> name2 >> time2;
                cin >> name3 >> time3;
    
                //Map inputs -> outputs
                cout << "Their names, then their times\n";
    
                if(time1 < 0 || time2 < 0 || time3 < 0) {       // Check if times are less than 0
                    cout << "Only positive values are allowed"; // Spits out an error and ends program if times are less than 0
                    break;
                }
    
                // Orders the times and prints the names and times in order.
                if(time1<time2 && time1<time3) {
                    cout << name1 << "\t" << setw(3) << time1 << endl;
        
                    if(time2<time3) {
                        cout << name2 << "\t" << setw(3) << time2 << endl;
                        cout << name3 << "\t" << setw(3) << time3;
            
                    } else if(time3<time2) {
                        cout << name3 << "\t" << setw(3) << time3 << endl;
                        cout << name2 << "\t" << setw(3) << time2;
            
                    }
                } else if(time2<time1 && time2<time3) {
                    cout << name2 << "\t" << setw(3) << time2 << endl;
        
                    if(time1<time3) {
                        cout << name1 << "\t" << setw(3) << time1 << endl;
                        cout << name3 << "\t" << setw(3) << time3;
            
                    } else if(time3<time1) {
                        cout << name3 << "\t" << setw(3) << time3 << endl;
                        cout << name1 << "\t" << setw(3) << time1;
                    }
                } else if(time3<time1 && time3<time2) {
                    cout << name3 << "\t" << setw(3) << time3 << endl;
        
                    if(time1<time2) {
                        cout << name1 << "\t" << setw(3) << time1 << endl;
                        cout << name2 << "\t" << setw(3) << time2;
            
                    } else if(time2<time1) {
                        cout << name2 << "\t" << setw(3) << time2 << endl;
                        cout << name1 << "\t" << setw(3) << time1;
            
                    }
                }
    
                
                cout << endl << endl;
                break;
            }
            case 4: {
                //Declare Variables
                char plannmb;   // the plan the user is using
                float hours,    // the hours the user has spent
                      othours;  // the hours the user has spent over the time limit
    
                // Package A
                float rateA = 9.95,   // hourly rate of plan a
                      maxhrsA = 10,   // max hours allowed on plan a
                      adhourA = 2.00; // the rate per additional hour used
    
                // Package B
                float rateB = 14.95,  // hourly rate of plan b
                      maxhrsB = 20,   // max hours allowed on plan b
                      adhourB = 1.00; // the rate per additional hour used
    
                // Package C
                float rateC = 19.95;  // hourly rate of plan c
    
                float bill;
    
                //Initialize or input i.e. set variable values
                cout << "ISP Bill\nInput Package and Hours\n";
                cin >> plannmb >> hours;
    
                //Map inputs -> outputs
                switch(plannmb) {
                    case 'A': 
                        othours = hours>maxhrsA? (hours-maxhrsA):0;
                        bill = rateA + (othours*adhourA);
                        break;
                    case 'B': 
                        othours = hours>maxhrsB? (hours-maxhrsB):0;
                        bill = rateB + (othours*adhourB);
                        break;
                    case 'C': 
                        bill = rateC;
                        break;
    }
    
                //Display the outputs
                cout << fixed << setprecision(2) << "Bill = $ " << bill;
                
                
                cout << endl << endl;
                break; 
            }
            case 5: {
                //Declare Variables
                string in1, in2;
    
                //Initialize or input i.e. set variable values
                cout << "Rock Paper Scissors Game\nInput Player 1 and Player 2 Choices\n";
                cin >> in1 >> in2;
    
                //Map inputs -> outputs and display
                // converts lowercase to uppercase
                if(in1 == "p") in1 = "P";
                if(in1 == "s") in1 = "S";
                if(in1 == "r") in1 = "R";
                if(in2 == "p") in2 = "P";
                if(in2 == "s") in2 = "S";
                if(in2 == "r") in2 = "R";
    
                // reads inputs and determines who wins
                if((in1 == "P" && in2 == "S") || (in1 == "S" && in2 == "P")) { //determines between paper and scissors
                    cout << "Scissors cuts paper.";
        
                } else if((in1 == "P" && in2 == "R") || (in1 == "R" && in2 == "P")) {
                    cout << "Paper covers rock.";
        
                } else if((in1 == "S" && in2 == "R") || (in1 == "R" && in2 == "S")) {
                    cout << "Rock breaks scissors.";
        
                } else {
                    cout << "Nobody wins.";
                }
                
                
                cout << endl << endl;
                break; 
            }
            case 6: {
                //Declare Variables
                int number,    // the arabic number the user will input
                    thous,     // the number of 1000s
                    hund,      // the number of 100s
                    tens,      // the number of 10s
                    ones;      // the number of 1s
                string romanN; // the roman numeral to be output
    
                //Initialize or input i.e. set variable values
                cout << "Arabic to Roman numeral conversion.\nInput the integer to convert.\n";
                cin >> number;
    
                //Map inputs -> outputs
    
                if(number>3000 || number<1000) {             // Filters out inputs which are
                    cout << number << " is Out of Range!";   // out of range
                    return 0;
                }
    
                thous = number/1000;
                number = number - thous*1000;
                hund = number/100;
                number = number - hund*100;
                tens = number/10;
                number = number - tens*10;
                ones = number;
    
                // Add the thousands
                switch(thous) {
                    case 3: romanN = "MMM";
                    break;
                    case 2: romanN = romanN + "MM";
                    break;
                    case 1: romanN = romanN + "M";
                    break;
                }
    
                // Add the hundreds
                switch(hund) {
                    case 9: romanN = romanN + "CM";
                            break;
                    case 8: romanN = romanN + "DCCC";
                            break;
                    case 7: romanN = romanN + "DCC";
                            break;
                    case 6: romanN = romanN + "DC";
                            break;
                    case 5: romanN = romanN + "D";
                            break;
                    case 4: romanN = romanN + "CD";
                            break;
                    case 3: romanN = romanN + "CCC";
                            break;
                    case 2: romanN = romanN + "CC";
                            break;
                    case 1: romanN = romanN + "C";
                            break;
                }
    
                // Add the tens
                switch(tens) {
                    case 9: romanN = romanN + "XC";
                            break;
                    case 8: romanN = romanN + "LXX";
                            break;
                    case 7: romanN = romanN + "LXX";
                            break;
                    case 6: romanN = romanN + "LX";
                            break;
                    case 5: romanN = romanN + "L";
                            break;
                    case 4: romanN = romanN + "XL";
                            break;
                    case 3: romanN = romanN + "XXX";
                            break;
                    case 2: romanN = romanN + "XX";
                            break;
                    case 1: romanN = romanN + "X";
                            break;
                }
    
                // Add the ones
                switch(tens) {
                    case 9: romanN = romanN + "IX";
                            break;
                    case 8: romanN = romanN + "VIII";
                            break;
                    case 7: romanN = romanN + "VII";
                            break;
                    case 6: romanN = romanN + "VI";
                            break;
                    case 5: romanN = romanN + "V";
                            break;
                    case 4: romanN = romanN + "IV";
                            break;
                    case 3: romanN = romanN + "II";
                            break;
                    case 2: romanN = romanN + "II";
                            break;
                    case 1: romanN = romanN + "I";
                            break;
                }
    
                number = thous*1000 + hund*100 + tens*10 + ones; // recreate the input number
    
                //Display the outputs
                cout << number << " is equal to " << romanN;
                
                
                cout << endl << endl;
                break; 
            }
            case 7: {
                //Declare Variables
                string sign1, sign2, 
                       elmnt1 = "", 
                       elmnt2 = " ";
    
                //Initialize or input i.e. set variable values
                // FIRE
                cout << "Horoscope Program which examines compatible signs.\nInput 2 signs.\n";
                cin >> sign1 >> sign2;
    
   
                //Map inputs -> outputs
    
                if(sign1 == "aries") sign1 = "Aries";
                else if (sign1 == "leo") sign1 = "Leo";
                else if (sign1 == "sagittarius") sign1 = "Sagittarius";
                else if (sign1 == "virgo") sign1 = "Virgo";
                else if (sign1 == "taurus") sign1 = "Taurus";
                else if (sign1 == "capicorn") sign1 = "Capricorn";
                else if (sign1 == "gemini") sign1 = "Gemini";
                else if (sign1 == "libra") sign1 = "Libra";
                else if (sign1 == "aquarius") sign1 = "Aquarius";
                else if (sign1 == "cancer") sign1 = "Cancer";
                else if (sign1 == "scorpio") sign1 = "Scorpio";
                else if (sign1 == "pisces") sign1 = "Pisces";
    
                if(sign2 == "aries") sign2 = "Aries";
                else if (sign2 == "leo") sign2 = "Leo";
                else if (sign2 == "sagittarius") sign2 = "Sagittarius";
                else if (sign2 == "virgo") sign2 = "Virgo";
                else if (sign2 == "taurus") sign2 = "Taurus";
                else if (sign2 == "capicorn") sign2 = "Capricorn";
                else if (sign2 == "gemini") sign2 = "Gemini";
                else if (sign2 == "libra") sign2 = "Libra";
                else if (sign2 == "aquarius") sign2 = "Aquarius";
                else if (sign2 == "cancer") sign2 = "Cancer";
                else if (sign2 == "scorpio") sign2 = "Scorpio";
                else if (sign2 == "pisces") sign2 = "Pisces";
    
                // Assigns FIRE element
                if(sign1 == "Aries" || sign1 == "Leo" || sign1 == "Sagittarius") {
                    elmnt1 = "Fire";
                }
                if(sign2 == "Aries" || sign2 == "Leo" || sign2 == "Sagittarius") {
                    elmnt2 = "Fire";
                }
    
                // Assigns EARTH element
                if(sign1 == "Virgo" || sign1 == "Taurus" || sign1 == "Capricorn") {
                    elmnt1 = "Earth";
                }
                if(sign2 == "Virgo" || sign2 == "Taurus" || sign2 == "Capricorn") {
                    elmnt2 = "Earth";
                }
    
                // Assigns AIR element
                if(sign1 == "Gemini" || sign1 == "Libra" || sign1 == "Aquarius") {
                    elmnt1 = "Air";
                }  
                if(sign2 == "Gemini" || sign2 == "Libra" || sign2 == "Aquarius") {
                    elmnt2 = "Air";
                } 
    
                // Assigns WATER element
                if(sign1 == "Cancer" || sign1 == "Scorpio" || sign1 == "Pisces") {
                    elmnt1 = "Water";
                } 
                if(sign2 == "Cancer" || sign2 == "Scorpio" || sign2 == "Pisces") {
                    elmnt2 = "Water";
                } 
    
    
    
                //Display the outputs
                if(elmnt1 == elmnt2) {                                                              // COMPARES ELEMENTS
                    cout << sign1 << " and " << sign2 << " are compatible " << elmnt1 << " signs."; // compatible
                } else {                                                                            // IF ELEMENTS ARE INCOMPATIBLE
                    cout << sign1 << " and " << sign2 << " are not compatible signs.";              // outputs incompatible
                }
      
                
                cout << endl << endl;
                break; 
            }

            case 8:cout<<"Place Problem 8 here"<<endl;break;
            case 9:cout<<"Place Problem 9 here"<<endl;break;
            default:cout<<"Exiting the Menu"<<endl;
        }
    }while(choose>=0 && choose<=9);

    return 0;
}