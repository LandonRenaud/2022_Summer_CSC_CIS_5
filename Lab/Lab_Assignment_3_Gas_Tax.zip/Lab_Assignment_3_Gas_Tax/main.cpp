/* 
 * File:   main.cpp
 * Author: Landon Renaud
 * Created on July 7, 2022, 7:41 PM
 * Purpose:
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants
//Mathematical/Physics/Conversions, Higher dimensioned arrays

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    
    //Declare Variables
    float price,           // Gas Price           all taxes are a /gallon basis
          SexcsT = 0.39,   // State excise Tax
          salesT = 0.08,   // State sales Tax
          ctfee = 0.10,    // Cap and Trade Fee
          FexcsT = 0.184,  // Federal excise Tax
          profit = 0.065,  // Oil Company Profit
          revenue,         // The total profit in dollars made by the oil company
          taxmny,          // The total tax revenue generated
          govprct,         // the percent of the price the government collected as tax money
          oilprct;         // The percent of the price the oil company earned as profit
            
    //Initialize Variables
    cout << "How much did you pay per gallon\nthe last time you filled up your car? ";
    cin >> price;
    
    //Map inputs to outputs -> The Process
    revenue = price*profit;
    taxmny = salesT*price + SexcsT + ctfee + FexcsT;
    oilprct = profit*100;
    govprct = (taxmny/price)*100;

    //Display Results
    cout << fixed << setprecision(2);
    cout << "\nThe oil company earned $" << revenue << " dollars per gallon from your purchase.\n";
    cout << "The oil company made a profit of " << oilprct << "%.\n";
    cout << "The government collected $" << taxmny << " dollars per gallon from your purchase.\n";
    cout << "This value is equal to " << govprct << "% of your purchase.\n\n";
    
    (revenue<taxmny)? cout << "The government collected more money than the oil company earned from your purchase.\n":
                      cout << "The oil company earned more money than the government collected from your purchase.\n";
    
    (oilprct<govprct)? cout << "The government collected a higher percentage than the oil company earned.\n":
                       cout << "The oil company earned a higher percentage than the government collected.\n";

    //Exit stage right
    return 0;
}

